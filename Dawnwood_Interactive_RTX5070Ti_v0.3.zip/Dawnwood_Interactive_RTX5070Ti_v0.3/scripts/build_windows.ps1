# Run from a Visual Studio 2022 Developer PowerShell with CUDA >=12.8 installed.
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Push-Location $Root
try {
    & cmake -S . -B build -A x64 '-DCMAKE_CUDA_ARCHITECTURES=120-real;120-virtual'
    if ($LASTEXITCODE -ne 0) { throw 'CMake configuration failed' }
    & cmake --build build --config Release --parallel
    if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
    & ctest --test-dir build -C Release --output-on-failure -LE gpu
    if ($LASTEXITCODE -ne 0) { throw 'CPU tests failed' }
    Write-Host 'Built build\Release\dawnwood.exe. Run --self-test next.'
} finally { Pop-Location }
