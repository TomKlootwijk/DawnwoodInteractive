# Dawnwood Interactive — v0.3

Tom Klootwijk · NL200678942 · 10-07-1990

The v0.2 unified symbolic workbench is followed by an explicit native numerical
binding: packed CUDA BC5/RG8 texture fields, device-owned circulation, mutable
operator words and SDF supports, a shared-memory hot set, requested L2 policy,
automatic capacity packing, chained reads, ordered commits and complete snapshots.

`docs/NATIVE_BINDING.md` defines the executable choices and
`docs/SOURCE_MAP.md` connects them to the original 24-page source. The exact
validation performed for this release is recorded in `results/VALIDATION.json`.
