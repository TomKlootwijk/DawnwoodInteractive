# Original-source claims and the tests attached to them

All source references below point to the unchanged `source/double-slit-theory.pdf`. The source contains both the author's proposals and earlier AI responses. Architectural requirements and the AI's stronger performance/physics assertions are tracked separately. The numerical equations used by the tests are DWI-N1 bindings documented in `NUMERICAL_PROFILE.md`.

| ID | Source pages / claim | Executable evidence or measurement | What its outcome establishes |
|---|---|---|---|
| S01 | 3–5: double pinion, Hadamard hinge, two streams | CPU involution/norm fixtures; full-cycle norm error; all-state CPU/Vulkan comparison | Numerical hinge and pinion behavior for N1. |
| S02 | 4–5: 7/54 one-bit parity and zero-based addressing | Exact parity fixture; distinction from integer parity; child-address test | Exact integer relationships in the stated example. |
| S03 | 6: 756 and `[0,2,0,1]` FT wavefront | Exact seed-component test; separate forward-DFT fixture | Preserves the source assignment; no unprovided general timestamp encoder is inferred. |
| S04 | 7: Y-up twice in fourth RK4 timeslot | Compare enabled/disabled Y-up; require first three slopes unchanged and fourth changed | The double event is active in the actual derivative evaluation, not a label. |
| S05 | 8–9: geometric LUT, colon, delta-delta-phi, phyllotaxis, blend | Primitive sign/zero fixtures; body edits; per-operator numerical state sensitivity | All source primitive groups and coupling stages participate under the declared bindings. |
| S06 | 9–12: A means inverse T | Matrix inverse residual; inverse-response feedback test | Computes and carries the inverse. A separate noise counterexample tests the stronger error-correction assertion. |
| S07 | 12–16: self-referential Klein carrier and pinion confinement | Negative/positive/double seam tests; analytic embedding identification; chart-domain health | State and operator transport obey the chosen Klein quotient, not a sphere substitute. |
| S08 | 14–16: jitter changes the acting operators in the LUT/BST | GPU mutation pass; numerical body-edit sensitivity; changed body/position records; CPU/Vulkan comparison | Operator definitions and surface positions actually change and affect later computation. |
| S09 | 11–14: R/G pairing, B history, A inverse; optional Bayer | Norm/history/inverse fixtures; checkpoint inspection; downstream Bayer test/readout | The defined channels/history remain connected; display output is outside the recurrence. |
| S10 | 18–21, earlier AI: permanent cache residence and zero PCIe traffic | Probe on-chip limits and budgets; count explicit transfer commands; time dispatch batches; optional vendor trace | `advance()` issues no buffer copy commands, but this is not a measurement proving permanent cache occupancy or all-zero bus traffic. Initialization/readout transfers are counted. |
| S11 | 19–22: BC5 dichromatic packing | Actual BC5 encoder/decoder, byte/block tests, reconstruction RMSE, device-format feature probe | Tests format size and approximation. The full exact state is not silently replaced by one compressed texel. |
| S12 | 20–22, earlier AI: billions of complete states and 24–48-billion pointer-free expansion | GB/GiB arithmetic; full 128-byte/64-byte ABI accounting; actual allocation/budget report; pointer-byte counterexample | Separates raw texels from complete operational states. The source supplies no byte width for the later 24–48-billion scenario. |
| S13 | 21–22: O(1) lookup/control and O(log N) route; earlier AI's global performance conclusions | Exact d-step child traversal; operator/state counts; measured count-scaling runs | One lookup/control update and a complete N-state interval are different workloads. No exponential comparison baseline is invented. |
| S14 | 15–16, earlier AI: jitter guarantees no deadlock/self-optimization | Jitter/feedback ablations and replay; explicit stationary-system counterexample to the generic inference | Shows active jitter/feedback where measured. A one-bit input alone cannot logically guarantee escape or optimization. |
| S15 | 13–17, earlier AI: topology prevents collapse / advances physical double-slit theory | Classical coherent-versus-incoherent interference fixture; external-observation evaluation utility | These are numerical predictions, not detector measurements. A distinct physical prediction and measured data are needed to test a new physical law. |
| S16 | 22–23, earlier AI: universal expressibility/Turing completeness | Conditional routing, editable bodies, persistent state and recurrence; cardinality test | Demonstrates those implemented mechanisms. A scalable encoding/simulation proof is not replaced by a finite regression PASS. |
| S17 | 19–21, earlier AI: golden-angle arrangement ensures optimal/coalesced GPU work | Inspect actual phyllotaxis placement and gather device timings | The default workload uses phyllotaxis; optimality/locality improvement requires a controlled, semantically equivalent scheduling comparison. No unmeasured speedup is filled in. |

## Actual reports

For the v0.4 revision, use `results/v0.4/VALIDATION.md` and `results/v0.4/summary.json`. They supersede historical v0.3 run claims and retain longer-horizon disagreements and real-phone failures. A passing short-run suite is not a claim of arbitrary-horizon backend equivalence. S07 establishes the stated discrete position/orientation wrapping; smooth Klein tangent covariance and asymmetric operator-frame transport remain unestablished.

`results/STATUS.md` is generated from commands run for this archive. `results/claims/summary.json`, individual JSON reports and command stdout/stderr give the evidence. A failed test remains failed. A missing device is recorded as unavailable, not assigned a successful outcome.

`tools/run_claims.py --device "1650 Ti"` performs the desktop device run without allowing a software ICD. `tools/test_phone.py` launches the actual Android application through an authorized ADB connection and retrieves its numerical and device reports. It records Android system RAM and thermal status separately from Vulkan memory heaps; the phone's 12 GB system RAM is not treated as 12 GB dedicated VRAM.

## Reading numerical operator coverage

The suite changes each active operator body and compares a **state-only digest**, not merely a digest containing the edited instruction word. A numerical-state change establishes that the edited definition participates in the circulation. Indices 25 (Bayer) and 26 (BC5) are deliberately tested in downstream tools rather than fed into the core. The full state-and-operator digest is separately used for exact same-environment checkpoint replay.

## Physical-observation interface

`tools/evaluate_experiment.py` accepts three explicit CSV files: observed detector counts, candidate expected counts, and reference expected counts. It computes descriptive Poisson-deviance scores at identical supplied positions. No observations are fabricated. A lower score for one supplied prediction would be a result about that dataset and its experimental design, not an automatic proof of a universal physical claim.

## Numerical counterexamples are results

The suite deliberately includes successful tests whose result is a counterexample: inverse transforms do not automatically delete added noise; scaled scalar fields need not be exact metric SDFs; pointer removal only saves pointers actually present; and a fixed b-bit store cannot losslessly encode all longer arbitrary strings. These tests concern specific statements in the source discussion, not a blanket verdict on the Dawnwood architecture.
