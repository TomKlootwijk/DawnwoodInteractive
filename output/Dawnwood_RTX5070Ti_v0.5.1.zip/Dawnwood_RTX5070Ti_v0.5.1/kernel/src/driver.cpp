#include "runtime.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <functional>
#include <cstdio>
#include <utility>
void validate_state(const State& a,uint i,const Config& cfg){std::array<uint,32> words{};std::memcpy(words.data(),&a,sizeof(a));
  for(uint k=0;k<32;++k)if(k<24||k>=28){float x;std::memcpy(&x,&words[k],sizeof(x));if(!std::isfinite(x))throw std::runtime_error("Nonfinite state["+std::to_string(i)+"].word["+std::to_string(k)+"]");}
  if(!(a.u>=0&&a.u<1&&a.v>=0&&a.v<1)||a.orientation>1||a.route>=cfg.opCount||a.alpha_ref!=i||!(a.lastJitter==0||a.lastJitter==1))throw std::runtime_error("Invalid chart, orientation, route, inverse reference or jitter in state["+std::to_string(i)+"]");
 }
void validate_snapshot(const Snapshot& s,bool statesRequired){
 validate_config(s.cfg);
 if((statesRequired?s.states.size()!=s.cfg.count:!s.states.empty())||s.ops.size()!=s.cfg.opCount)throw std::runtime_error("Snapshot record counts do not match configuration");
 for(uint i=0;i<s.states.size();++i)validate_state(s.states[i],i,s.cfg);
 for(size_t i=0;i<s.ops.size();++i){const auto& a=s.ops[i];std::array<float,12> fields{};std::memcpy(fields.data(),&a,sizeof(fields));
  for(float x:fields)if(!std::isfinite(x))throw std::runtime_error("Nonfinite operator["+std::to_string(i)+"]");
  if(!(a.u>=0&&a.u<1&&a.v>=0&&a.v<1&&a.radius>0&&a.height>0))throw std::runtime_error("Invalid chart or shape dimensions in operator["+std::to_string(i)+"]");
  for(uint k=0;k<8;++k)if(((a.program>>(4*k))&15)>8)throw std::runtime_error("Unknown bytecode instruction in operator["+std::to_string(i)+"]");
 }
}
std::string json_escape(const std::string& s){std::ostringstream o;o<<'"';for(unsigned char c:s){switch(c){case '"':o<<"\\\"";break;case '\\':o<<"\\\\";break;case '\n':o<<"\\n";break;case '\r':o<<"\\r";break;case '\t':o<<"\\t";break;default:if(c<32)o<<"\\u"<<std::hex<<std::setw(4)<<std::setfill('0')<<uint(c)<<std::dec;else o<<c;}}o<<'"';return o.str();}
namespace {
const char* stateNames[32]={"u","v","rho","theta","ar","ai","br","bi","history","inv00","inv01","inv10","inv11","field","delta","energy","px","py","pz","pw","k1v","k2v","k3v","k4v","rng","orientation","route","alpha_ref","previousTheta","previousPreviousTheta","phaseResponse","lastJitter"};
uint64_t hash_bytes(const void* data,size_t bytes,uint64_t h=14695981039346656037ull){auto p=static_cast<const unsigned char*>(data);for(size_t i=0;i<bytes;++i){h^=p[i];h*=1099511628211ull;}return h;}
std::string digest(const Snapshot& s){auto h=hash_bytes(s.states.data(),s.states.size()*sizeof(State));h=hash_bytes(s.ops.data(),s.ops.size()*sizeof(Operator),h);std::ostringstream o;o<<std::hex<<std::setw(16)<<std::setfill('0')<<h;return o.str();}
std::string state_digest(const Snapshot& s){auto h=hash_bytes(s.states.data(),s.states.size()*sizeof(State));std::ostringstream o;o<<std::hex<<std::setw(16)<<std::setfill('0')<<h;return o.str();}
std::string config_json(const Config& c){std::ostringstream o;o<<std::setprecision(std::numeric_limits<float>::max_digits10)<<"{\"count\":"<<c.count<<",\"operators\":"<<c.opCount<<",\"epoch\":"<<c.epoch<<",\"depth\":"<<c.depth<<",\"dt\":"<<c.dt<<",\"yup\":"<<c.yup<<",\"epsilon\":"<<c.epsilon<<",\"mutation\":"<<c.mutation<<",\"jitter\":"<<c.jitter<<",\"feedback\":"<<c.feedback<<",\"phaseRate\":"<<c.phaseRate<<",\"radialRate\":"<<c.radialRate<<",\"historyWeight\":"<<c.historyWeight<<",\"fieldScale\":"<<c.fieldScale<<",\"state_bytes\":"<<sizeof(State)<<",\"operator_bytes\":"<<sizeof(Operator)<<"}";return o.str();}
void write_checkpoint(const std::string& name,const Snapshot& s){validate_snapshot(s);std::ofstream f(name,std::ios::binary);if(!f)throw std::runtime_error("Cannot open checkpoint: "+name);const char magic[8]={'D','W','K','N','0','0','0','3'};uint sizes[2]={sizeof(State),sizeof(Operator)};f.write(magic,8);f.write(reinterpret_cast<char*>(sizes),8);f.write(reinterpret_cast<const char*>(&s.cfg),sizeof(Config));f.write(reinterpret_cast<const char*>(s.states.data()),std::streamsize(s.states.size()*sizeof(State)));f.write(reinterpret_cast<const char*>(s.ops.data()),std::streamsize(s.ops.size()*sizeof(Operator)));f.close();if(!f)throw std::runtime_error("Checkpoint write failed");}
Snapshot read_checkpoint(const std::string& name){std::ifstream f(name,std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error("Cannot read checkpoint: "+name);auto bytes=f.tellg();f.seekg(0);char magic[8];uint sizes[2];Snapshot s;f.read(magic,8);f.read(reinterpret_cast<char*>(sizes),8);f.read(reinterpret_cast<char*>(&s.cfg),sizeof(Config));if(!f||std::memcmp(magic,"DWKN0003",8)||sizes[0]!=sizeof(State)||sizes[1]!=sizeof(Operator))throw std::runtime_error("Checkpoint header/ABI mismatch");validate_config(s.cfg);uint64_t expected=80ull+uint64_t(s.cfg.count)*sizeof(State)+uint64_t(s.cfg.opCount)*sizeof(Operator);if(expected!=uint64_t(bytes))throw std::runtime_error("Checkpoint size does not match header");s.states.resize(s.cfg.count);s.ops.resize(s.cfg.opCount);f.read(reinterpret_cast<char*>(s.states.data()),s.states.size()*sizeof(State));f.read(reinterpret_cast<char*>(s.ops.data()),s.ops.size()*sizeof(Operator));if(!f)throw std::runtime_error("Checkpoint read failed");validate_snapshot(s);return s;}
struct Comparison {uint64_t floatMismatch=0,integerMismatch=0,nonfinite=0,invalidSnapshots=0,bitwiseMismatch=0;double worstScaled=0,maxAbsolute=0;std::string first;bool pass()const{return !floatMismatch&&!integerMismatch&&!nonfinite&&!invalidSnapshots;}};
Comparison compare(const Snapshot& a,const Snapshot& b,double atol=1e-5,double rtol=2e-5){Comparison c;
 try{validate_snapshot(a);}catch(const std::exception& e){++c.invalidSnapshots;c.first=std::string("cpu: ")+e.what();}
 try{validate_snapshot(b);}catch(const std::exception& e){++c.invalidSnapshots;if(c.first.empty())c.first=std::string("vulkan: ")+e.what();}
 if(a.states.size()!=b.states.size()||a.ops.size()!=b.ops.size()){if(!c.invalidSnapshots)++c.invalidSnapshots;if(c.first.empty())c.first="Snapshot record counts differ";return c;}
 auto scalar=[&](float x,float y,const std::string& where){if(!std::isfinite(x)||!std::isfinite(y)){++c.nonfinite;if(c.first.empty())c.first=where+": nonfinite";return;}double d=std::abs(double(x)-y),scaled=d/(atol+rtol*std::max(std::abs(double(x)),std::abs(double(y))));c.maxAbsolute=std::max(c.maxAbsolute,d);c.worstScaled=std::max(c.worstScaled,scaled);if(scaled>1){++c.floatMismatch;if(c.first.empty()){std::ostringstream o;o<<where<<" cpu="<<std::setprecision(9)<<x<<" vulkan="<<y;c.first=o.str();}}};
 for(size_t i=0;i<a.states.size();++i){std::array<uint,32>x{},y{};std::memcpy(x.data(),&a.states[i],128);std::memcpy(y.data(),&b.states[i],128);for(uint k=0;k<32;++k){if(x[k]!=y[k])++c.bitwiseMismatch;std::string where="state["+std::to_string(i)+"]."+stateNames[k];if(k>=24&&k<28){if(x[k]!=y[k]){++c.integerMismatch;if(c.first.empty())c.first=where;}}else{float xx,yy;std::memcpy(&xx,&x[k],4);std::memcpy(&yy,&y[k],4);scalar(xx,yy,where);}}}
 for(size_t i=0;i<a.ops.size();++i){std::array<uint,16>x{},y{};std::memcpy(x.data(),&a.ops[i],64);std::memcpy(y.data(),&b.ops[i],64);for(uint k=0;k<16;++k){if(x[k]!=y[k])++c.bitwiseMismatch;std::string where="operator["+std::to_string(i)+"].word["+std::to_string(k)+"]";if(k>=12){if(x[k]!=y[k]){++c.integerMismatch;if(c.first.empty())c.first=where;}}else{float xx,yy;std::memcpy(&xx,&x[k],4);std::memcpy(&yy,&y[k],4);scalar(xx,yy,where);}}}
 return c;}
std::string comparison_json(const Comparison& c){std::ostringstream o;o<<std::setprecision(10)<<"{\"passed\":"<<(c.pass()?"true":"false")<<",\"bitwise_word_mismatches\":"<<c.bitwiseMismatch<<",\"bitwise_equal\":"<<(c.bitwiseMismatch==0&&c.invalidSnapshots==0?"true":"false")<<",\"float_mismatches\":"<<c.floatMismatch<<",\"integer_mismatches\":"<<c.integerMismatch<<",\"nonfinite_values\":"<<c.nonfinite<<",\"invalid_snapshots\":"<<c.invalidSnapshots<<",\"worst_scaled_error\":"<<c.worstScaled<<",\"max_absolute_error\":"<<c.maxAbsolute<<",\"first_mismatch\":"<<json_escape(c.first)<<"}";return o.str();}
struct StateHealth {
 uint64_t nonfinite=0,badChart=0,checked=0;double maxEnergy=0;bool energyFinite=true;std::string failure;
 void add(const State* data,uint base,uint count,const Config& cfg){
  for(uint i=0;i<count;++i){const auto& a=data[i];uint words[32];std::memcpy(words,&a,128);
   for(uint k=0;k<32;++k)if(k<24||k>=28){float x;std::memcpy(&x,&words[k],4);if(!std::isfinite(x))++nonfinite;}
   if(!(a.u>=0&&a.u<1&&a.v>=0&&a.v<1))++badChart;
   if(std::isfinite(a.energy))maxEnergy=std::max(maxEnergy,std::abs(double(a.energy)-5));else energyFinite=false;
   try{validate_state(a,base+i,cfg);}catch(const std::exception& e){if(failure.empty())failure=e.what();}
  }checked+=count;
 }
 std::string report(uint expected){if(checked!=expected&&failure.empty())failure="Incomplete state readback";std::ostringstream o;
  o<<"{\"passed\":"<<(failure.empty()?"true":"false")<<",\"first_invalid_record\":"<<json_escape(failure)<<",\"checked_state_records\":"<<checked<<",\"nonfinite_state_values\":"<<nonfinite<<",\"out_of_chart_states\":"<<badChart<<",\"max_energy_error_from_source_seed_5\":";
  if(energyFinite)o<<maxEnergy;else o<<"null";o<<"}";return o.str();
 }
};
std::string health(const Snapshot& s){StateHealth value;try{validate_snapshot(s);}catch(const std::exception& e){value.failure=e.what();}value.add(s.states.data(),0,uint(s.states.size()),s.cfg);return value.report(s.cfg.count);}
std::string hash_text(uint64_t value){std::ostringstream o;o<<std::hex<<std::setw(16)<<std::setfill('0')<<value;return o.str();}

struct Test {std::string name;bool pass;std::string detail;};
std::string selftests(){std::vector<Test> tests;auto test=[&](std::string n,std::function<bool()> f,std::string detail=""){bool p=false;try{p=f();}catch(const std::exception& e){detail=e.what();}tests.push_back({n,p,detail});};
 test("source_7_54_population_parity",[]{return dw_parity(7)==1&&dw_parity(54)==0;});
 test("population_parity_is_not_integer_parity",[]{return dw_parity(3)==0&&(3u&1u)==1;});
 test("source_wavefront_components",[]{auto s=initialize(default_config(1));auto a=s.states[0];return a.ar==0&&a.ai==2&&a.br==0&&a.bi==1&&a.energy==5;});
 test("record_ABI",[]{return sizeof(State)==128&&sizeof(Operator)==64&&sizeof(Config)==64;});
 test("implicit_tree_children",[]{uint i=0;i=2*i+1;i=2*i+2;return i==4;});
 test("Klein_positive_seam",[]{float u=1.125f,v=.25f;uint o=0;dw_wrap(u,v,o);return u==.125f&&v==.75f&&o==1;});
 test("Klein_negative_seam",[]{float u=-.125f,v=.25f;uint o=0;dw_wrap(u,v,o);return u==.875f&&v==.75f&&o==1;});
 test("Klein_double_wrap_restores_orientation",[]{float u=2.125f,v=.25f;uint o=0;dw_wrap(u,v,o);return u==.125f&&v==.25f&&o==0;});
 test("Klein_R4_embedding_identification",[]{State a{},b{};a.u=1.2f;a.v=.3f;b.u=.2f;b.v=-.3f;dw_embedding(a);dw_embedding(b);return std::abs(a.px-b.px)+std::abs(a.py-b.py)+std::abs(a.pz-b.pz)+std::abs(a.pw-b.pw)<5e-6f;});
 test("log_radial_scale_identity",[]{float r=.37f,k=1.3f;return std::abs(std::log(k*r)-(std::log(r)+std::log(k)))<1e-6f;});
 test("sphere_signed_distance",[]{return std::abs(dw_shape(4,0,0,0,.2f,.3f)+.2f)<1e-7f&&std::abs(dw_shape(4,.2f,0,0,.2f,.3f))<1e-7f;});
 test("circle_signed_distance",[]{return dw_shape(2,0,0,0,.2f,.3f)<0&&dw_shape(2,.3f,0,0,.2f,.3f)>0;});
 test("T_geometry_sign",[]{return dw_shape(0,0,0,0,.2f,.3f)<0&&dw_shape(0,2,2,2,.2f,.3f)>0;});
 test("pyramid_side_geometry_sign",[]{return dw_shape(1,0,0,0,.2f,.3f)<0;});
 test("cone_apex_and_interior",[]{return dw_shape(3,0,0,.3f,.2f,.3f)==0&&dw_shape(3,0,0,0,.2f,.3f)<0;});
 test("apex_point_field",[]{return dw_shape(5,0,0,0,.2f,.3f)==0&&dw_shape(5,.1f,0,0,.2f,.3f)>.09f;});
 test("scalar_bytecode_body_changes_result",[]{Operator a{};a.gain=.3f;a.program=1;Operator b=a;b.program=2;return dw_body(.5f,a)!=dw_body(.5f,b);});
 test("Hadamard_involution",[]{float a=2,b=1,x=(a+b)*.7071067811865475f,y=(a-b)*.7071067811865475f;return std::abs((x+y)*.7071067811865475f-a)<5e-7f&&std::abs((x-y)*.7071067811865475f-b)<5e-7f;});
 test("fourth_slot_double_Y_up_is_active",[]{auto a=initialize(default_config(8)),b=a;b.cfg.yup=0;cpu_step(a);cpu_step(b);return a.states[0].k1v==b.states[0].k1v&&a.states[0].k2v==b.states[0].k2v&&a.states[0].k3v==b.states[0].k3v&&a.states[0].k4v!=b.states[0].k4v;});
 test("operator_body_and_surface_position_change",[]{auto a=initialize(default_config(16));auto old=a.ops;for(int i=0;i<8;++i)cpu_step(a);bool body=false,position=false;for(uint i=0;i<a.cfg.opCount;++i){body|=old[i].program!=a.ops[i].program;position|=old[i].u!=a.ops[i].u||old[i].v!=a.ops[i].v;}return body&&position;});
 test("feedback_changes_future_numerical_state",[]{auto a=initialize(default_config(16)),b=a;b.cfg.feedback=0;for(int i=0;i<4;++i){cpu_step(a);cpu_step(b);}return digest(a)!=digest(b)&&a.states[0].theta!=b.states[0].theta;});
 test("live_body_edit_changes_future_numerical_state",[]{auto a=initialize(default_config(16)),b=a;b.ops[6].program=2;for(int i=0;i<4;++i){cpu_step(a);cpu_step(b);}return a.states[0].theta!=b.states[0].theta;});
 test("inverse_T_matrix_residual",[]{auto a=initialize(default_config(8));cpu_step(a);auto s=a.states[0];float t=s.theta+a.ops[19].phase+0.01f*dw_apply(s,a.ops[19],s.field),k=a.ops[19].shear,c=std::cos(t),sn=std::sin(t);float t00=c,t01=c*k-sn,t10=sn,t11=sn*k+c;return std::abs(t00*s.inv00+t01*s.inv10-1)+std::abs(t00*s.inv01+t01*s.inv11)+std::abs(t10*s.inv00+t11*s.inv10)+std::abs(t10*s.inv01+t11*s.inv11-1)<2e-6f;});
 test("inverse_is_not_automatic_noise_correction",[]{float x=1,y=2,noise=.01f;float tx=x+y,ty=y;float recovered=tx+noise-ty;return std::abs(recovered-x)>.009f;},"Counterexample witness: applying an inverse transform does not delete additive channel noise.");
 test("norm_preserved_in_full_numerical_cycle",[]{auto a=initialize(default_config(32));for(int i=0;i<128;++i)cpu_step(a);for(auto& s:a.states)if(std::abs(s.energy-5)>3e-4f)return false;return true;});
 test("same_seed_replay",[]{auto a=initialize(default_config(16)),b=a;for(int i=0;i<16;++i){cpu_step(a);cpu_step(b);}return digest(a)==digest(b);});
 test("history_participates_in_next_operator_change",[]{auto a=initialize(default_config(16)),b=a;b.states[0].history=1;cpu_step(a);cpu_step(b);return a.ops[0].phase!=b.ops[0].phase;});
 test("mutable_scalar_field_not_always_metric_SDF",[]{Operator a{};a.gain=0;a.coupling=2;a.program=3;float left=dw_body(dw_shape(4,.3f,0,0,.2f,.3f),a),right=dw_body(dw_shape(4,.301f,0,0,.2f,.3f),a);float gradient=(right-left)/.001f;return gradient>1.9f;},"Counterexample witness: field scaling can violate the unit-gradient property of an exact SDF.");
 test("fixed_bit_store_cardinality",[]{return (uint64_t(1)<<8)<257u;},"A 256-pattern store cannot injectively encode 257 arbitrary distinct messages.");
 test("raw_GB_and_GiB_accounting",[]{return uint64_t(4)*1000000000ull!=uint64_t(4)*(1ull<<30)&&sizeof(State)>1;});
 bool pass=true;std::ostringstream o;o<<"{\"profile\":\"DWI-N1-0.5\",\"backend\":\"CPU\",\"tests\":[";for(size_t i=0;i<tests.size();++i){if(i)o<<",";auto& t=tests[i];pass&=t.pass;o<<"{\"name\":"<<json_escape(t.name)<<",\"passed\":"<<(t.pass?"true":"false")<<",\"detail\":"<<json_escape(t.detail)<<"}";}o<<"],\"tests_run\":"<<tests.size()<<",\"passed\":"<<(pass?"true":"false")<<"}";return o.str();}
struct Options {std::string command="verify",backend="vulkan",device,out,resume,checkpoint;bool allowSoftware=false,stream=false;uint count=256,ops=31,steps=16,batch=32,depth=4;float dt=.01f,yup=.0005f,mutation=1,budgetFraction=.8f;uint jitter=1,feedback=1;std::vector<std::pair<uint,uint>> edits;};
uint number(const std::string& s){if(s.empty()||s[0]<'0'||s[0]>'9')throw std::runtime_error("Expected uint32: "+s);size_t pos=0;auto x=std::stoull(s,&pos,0);if(pos!=s.size()||x>UINT32_MAX)throw std::runtime_error("Expected uint32: "+s);return uint(x);}
float real_number(const std::string& s){size_t pos=0;float x=std::stof(s,&pos);if(pos!=s.size()||!std::isfinite(x))throw std::runtime_error("Expected finite floating-point value: "+s);return x;}
Options parse(const std::vector<std::string>& args){Options o;size_t i=0;if(!args.empty()&&args[0].rfind("--",0)!=0){o.command=args[0];i=1;}for(;i<args.size();++i){auto k=args[i];if(k=="--allow-software"){o.allowSoftware=true;continue;}if(k=="--stream"){o.stream=true;continue;}if(i+1>=args.size())throw std::runtime_error("Missing value for "+k);auto v=args[++i];if(k=="--budget-fraction")o.budgetFraction=real_number(v);else if(k=="--backend")o.backend=v;else if(k=="--device")o.device=v;else if(k=="--out")o.out=v;else if(k=="--resume")o.resume=v;else if(k=="--checkpoint")o.checkpoint=v;else if(k=="--count")o.count=number(v);else if(k=="--operators")o.ops=number(v);else if(k=="--steps")o.steps=number(v);else if(k=="--batch")o.batch=number(v);else if(k=="--depth")o.depth=number(v);else if(k=="--dt")o.dt=real_number(v);else if(k=="--yup")o.yup=real_number(v);else if(k=="--mutation")o.mutation=real_number(v);else if(k=="--jitter")o.jitter=number(v);else if(k=="--feedback")o.feedback=number(v);else if(k=="--program"){auto sep=v.find(':');if(sep==std::string::npos)throw std::runtime_error("Use --program index:0xHEX");uint index=number(v.substr(0,sep)),code=number(v.substr(sep+1));for(uint j=0;j<8;++j)if(((code>>(4*j))&15)>8)throw std::runtime_error("Bytecode instruction must be 0..8");o.edits.emplace_back(index,code);}else throw std::runtime_error("Unknown option: "+k);}if(!(o.budgetFraction>0&&o.budgetFraction<=.98f))throw std::runtime_error("Budget fraction must be greater than zero and at most 0.98");if(o.command=="verify"&&!o.steps)throw std::runtime_error("Verification requires at least one epoch");if(!o.batch||o.jitter>1||o.feedback>1)throw std::runtime_error("Batch must be positive; jitter and feedback must be 0 or 1");if(o.stream&&(o.command!="run"||o.backend!="vulkan"||!o.resume.empty()))throw std::runtime_error("--stream requires a fresh Vulkan run; resume uses the normal checkpoint path");if(o.backend!="cpu"&&o.backend!="vulkan")throw std::runtime_error("Backend must be cpu or vulkan");return o;}
}
std::string execute(const std::vector<std::string>& args){auto o=parse(args);std::string result;
 if(o.command=="selftest")result=selftests();
 else {Config c=default_config(o.count,o.ops);c.depth=o.depth;c.dt=o.dt;c.yup=o.yup;c.mutation=o.mutation;c.jitter=o.jitter;c.feedback=o.feedback;Snapshot initial=o.resume.empty()?initialize(c,!o.stream):read_checkpoint(o.resume);for(auto e:o.edits){if(e.first>=initial.ops.size())throw std::runtime_error("Operator edit outside catalogue");initial.ops[e.first].program=e.second;}validate_snapshot(initial,!o.stream);c=initial.cfg;if((o.command=="run"||o.command=="verify")&&uint64_t(c.epoch)+o.steps>UINT32_MAX)throw std::runtime_error("Requested epochs exceed the uint32 epoch ABI");
  if(o.command=="probe"){VulkanRuntime gpu(initial,o.device,o.allowSoftware,o.budgetFraction);result="{\"profile\":\"DWI-N1-0.5\",\"device\":"+gpu.device_json()+"}";}
  else if(o.command=="verify"){VulkanRuntime gpu(initial,o.device,o.allowSoftware,o.budgetFraction);auto cpu=initial;Comparison total;uint checked=0;std::ostringstream trace;trace<<"[";for(uint k=0;k<o.steps;++k){cpu_step(cpu);gpu.advance(1);auto actual=gpu.download();auto comp=compare(cpu,actual);total.worstScaled=std::max(total.worstScaled,comp.worstScaled);total.maxAbsolute=std::max(total.maxAbsolute,comp.maxAbsolute);total.bitwiseMismatch+=comp.bitwiseMismatch;total.floatMismatch+=comp.floatMismatch;total.integerMismatch+=comp.integerMismatch;total.nonfinite+=comp.nonfinite;total.invalidSnapshots+=comp.invalidSnapshots;if(total.first.empty()&&!comp.first.empty())total.first="epoch "+std::to_string(cpu.cfg.epoch)+" "+comp.first;if(k)trace<<",";trace<<"{\"epoch\":"<<cpu.cfg.epoch<<",\"comparison\":"<<comparison_json(comp)<<"}";++checked;if(!comp.pass())break;}trace<<"]";std::ostringstream r;r<<"{\"profile\":\"DWI-N1-0.5\",\"kind\":\"CPU versus Vulkan every epoch, all state and operator words\",\"config\":"<<config_json(c)<<",\"epochs_requested\":"<<o.steps<<",\"epochs_checked\":"<<checked<<",\"atol\":0.00001,\"rtol\":0.00002,\"passed\":"<<((total.pass()&&checked==o.steps)?"true":"false")<<",\"aggregate\":"<<comparison_json(total)<<",\"device\":"<<gpu.device_json()<<",\"trace\":"<<trace.str()<<"}";result=r.str();}
  else if(o.command=="run"){
   using Clock=std::chrono::steady_clock;
   auto elapsed=[](Clock::time_point start){return std::chrono::duration<double>(Clock::now()-start).count();};
   Snapshot final;double seconds=0,setupSeconds=0,advanceWallSeconds=0,readbackSeconds=0,analysisSeconds=0;std::string device="null",fullDigest,stateDigest,healthReport;
   if(o.backend=="cpu"){
    final=std::move(initial);auto start=Clock::now();
    for(uint k=0;k<o.steps;++k)cpu_step(final);
    seconds=advanceWallSeconds=elapsed(start);
   }else{
    auto start=Clock::now();VulkanRuntime gpu(initial,o.device,o.allowSoftware,o.budgetFraction,o.stream);setupSeconds=elapsed(start);
    // Upload owns the device copy now. Release the source before allocating readback.
    initial=Snapshot{};start=Clock::now();
    for(uint done=0;done<o.steps;){uint batch=std::min(o.batch,o.steps-done);gpu.advance(batch);seconds+=gpu.last_seconds();done+=batch;}
    advanceWallSeconds=elapsed(start);start=Clock::now();
    if(o.stream){
     final=gpu.download_metadata();validate_snapshot(final,false);StateHealth stateHealth;uint64_t stateHash=14695981039346656037ull;
     std::ofstream checkpoint;std::string partial=o.checkpoint+".partial";
     if(!o.checkpoint.empty()){checkpoint.open(partial,std::ios::binary);if(!checkpoint)throw std::runtime_error("Cannot open streamed checkpoint");const char magic[8]={'D','W','K','N','0','0','0','3'};uint sizes[2]={sizeof(State),sizeof(Operator)};checkpoint.write(magic,8);checkpoint.write(reinterpret_cast<char*>(sizes),8);checkpoint.write(reinterpret_cast<const char*>(&final.cfg),sizeof(Config));}
     gpu.visit_states([&](const State* data,uint base,uint count){auto inspectionStart=Clock::now();stateHash=hash_bytes(data,size_t(count)*sizeof(State),stateHash);stateHealth.add(data,base,count,final.cfg);analysisSeconds+=elapsed(inspectionStart);if(checkpoint.is_open()){checkpoint.write(reinterpret_cast<const char*>(data),std::streamsize(count)*sizeof(State));if(!checkpoint)throw std::runtime_error("Streamed checkpoint state write failed");}});
     stateDigest=hash_text(stateHash);fullDigest=hash_text(hash_bytes(final.ops.data(),final.ops.size()*sizeof(Operator),stateHash));healthReport=stateHealth.report(final.cfg.count);
     if(checkpoint.is_open()){checkpoint.write(reinterpret_cast<const char*>(final.ops.data()),std::streamsize(final.ops.size())*sizeof(Operator));checkpoint.close();if(!checkpoint)throw std::runtime_error("Streamed checkpoint operator write failed");if(!stateHealth.failure.empty())throw std::runtime_error("Streamed checkpoint health failed: "+stateHealth.failure);if(std::rename(partial.c_str(),o.checkpoint.c_str()))throw std::runtime_error("Cannot commit streamed checkpoint; destination must not exist");}
    }else final=gpu.download();
    readbackSeconds=elapsed(start);device=gpu.device_json();
   }
   if(!o.stream){if(!o.checkpoint.empty())write_checkpoint(o.checkpoint,final);auto analysisStart=Clock::now();fullDigest=digest(final);stateDigest=state_digest(final);healthReport=health(final);analysisSeconds=elapsed(analysisStart);}
   std::ostringstream r;r<<std::setprecision(10)<<"{\"profile\":\"DWI-N1-0.5\",\"backend\":"<<json_escape(o.backend)
    <<",\"streamed_host_state\":"<<(o.stream?"true":"false")<<",\"readback_includes_analysis\":"<<(o.stream?"true":"false")<<",\"config\":"<<config_json(final.cfg)<<",\"new_epochs\":"<<o.steps<<",\"seconds\":"<<seconds
    <<",\"state_epochs_per_second\":"<<(seconds>0?double(c.count)*o.steps/seconds:0)
    <<",\"mean_epoch_milliseconds\":"<<(o.steps?seconds*1000/o.steps:0)
    <<",\"timing\":{\"runtime_setup_upload_seconds\":"<<setupSeconds<<",\"advance_wall_seconds\":"<<advanceWallSeconds
    <<",\"readback_seconds\":"<<readbackSeconds<<",\"digest_and_health_seconds\":"<<analysisSeconds<<"}"
    <<",\"state_and_operator_fnv1a64\":"<<json_escape(fullDigest)<<",\"state_only_fnv1a64\":"<<json_escape(stateDigest)
    <<",\"health\":"<<healthReport<<",\"device\":"<<device<<"}";result=r.str();
  }
  else throw std::runtime_error("Commands: selftest, probe, verify, run");}
 result.insert(1,"\"runtime_version\":\"0.5.1-rtx1\",");
 if(!o.out.empty()){std::ofstream f(o.out);if(!f)throw std::runtime_error("Cannot write report: "+o.out);f<<result<<"\n";f.close();if(!f)throw std::runtime_error("Report write failed: "+o.out);}return result;
}
