# RTX edition evidence

The current hardware campaign is in [evidence/REPORT.md](../../evidence/REPORT.md). Historical result files referenced by older kernel documentation remain in the original repository. This standalone package includes the current shader-build record here.
