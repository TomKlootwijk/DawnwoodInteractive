# Dawnwood RTX 5070 Ti Laptop edition

Runtime **0.5.1-rtx1** · Numerical profile **DWI-N1-0.5**.

Run this command from the package root for a streamed one-million-state workload:

```powershell
.\kernel\bin\windows-rtx5070ti\dawnwood.exe run --device 'RTX 5070 Ti' --stream --count 1048576 --steps 64 --batch 8 --budget-fraction .98
```

`kernel/scripts/run_rtx5070ti.ps1` also runs this workload in PowerShell 7.
Its `-Count`, `-Steps`, `-Output` and `-Checkpoint` parameters
select a different run. The executable is
`kernel/bin/windows-rtx5070ti/dawnwood.exe`.

If your shell disables scripts, use the direct executable command above.

- [Measured results and sustained-load trace](evidence/REPORT.md)
- [Runtime changes and build/run instructions](kernel/docs/RTX5070TI_v0.5.1.md)
- [Audited metrics and identities](evidence/completion_audit.json)

The installed NVIDIA Vulkan driver is used. Python is needed only for optional
measurement/manifest tools; it is not needed to run the executable. The source,
seven generated compute shaders, original source references and measurement
records are included. LLVM/MinGW runtime notices are in `third_party_licenses/`.

Verify the package with `python tools/verify_manifest.py`. To reproduce the
portable LLVM build, supply Python, Compiler, VulkanSDK, Binary, Evidence and
Name paths to `tools/build_rtx.ps1`. CMake is also supported from `kernel/`.
