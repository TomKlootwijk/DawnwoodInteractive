# Dawnwood Interactive
## Self-Referential Log-Polar Klein-Bottle Substrate — v0.1

Prepared for **Tom Klootwijk** from the uploaded `double-slit-theory.pdf`.

**Start with `docs/Dawnwood_Interactive_Formalization.pdf`.** This is a technical formalization and a proposed finite reference profile, not a company registration, quantum-device certification, universality proof or measured GPU implementation.

### Private working archive

This archive contains supplied identifiers and contact details in the private attribution record and private document, and personal information in the original source. The editable master LaTeX also contains the private appendix. **Do not publish this entire archive without reviewing it.** `docs/Dawnwood_Interactive_Public.pdf` excludes the private appendix and retains only the name/project attribution. It is the appropriate PDF for technical sharing.

## Run the CPU reference

Python **3.10 or later** is required. There are **no third-party runtime dependencies**. Open a terminal in this extracted directory:

```text
python tools/run_tests.py
python run.py demo --steps 128 --out results/my_run
python run.py memory --total-bytes 12884901888 --reserve-bytes 2147483648 --out results/my_budget.csv
```

The demo saves a JSON-lines trace, state snapshot and SHA-256 summary. It does not render an image, contact external services or allocate GPU memory. The memory command calculates storage scenarios only.

The release's default run is in `results/reference_run/`. It uses `config/reference.json`: 256 Boolean cells, seven operator descriptors, a 32-by-24 **coordinate chart** (not an image), seed 756 and a logical interval of 0.01 seconds. The 128-epoch run records 79 active evaluations, 38 descriptor-mode changes, four orientation changes and 66 jitter ones. Its state digest is:

```text
15b386758c0f548c2c3627c2f3c4a7c9853d69cf9c47330fbdfdc317a8aa7026
```

**Executed validation: 70 tests passed, zero failures/errors/skips**, on Python 3.13.5, Linux x86-64. This validates the tested reference rules, not the earlier AI's physical or performance claims. See `results/test_summary.json` and `results/test_report.txt`.

## What is implemented

The integrated finite interpreter combines an exact packed-bit payload, an actual ordered implicit BST, one-bit seeded jitter, feedback-controlled operator variants, mutable anchors, intrinsic Klein-quotient activation fields and orientation-aware double-pinion transport. The previous output influences the next operator choice and its mutation, providing an explicit form of self-reference.

Separate tested helpers define log-polar encoding, radial quantization, Hadamard mixing, the literal `[0,2,0,1]` DFT fixture, RK4, planar phyllotaxis, prototype primitive fields, a colon contraction, phase differences, blending, inverse-period alpha and optional ordered Bayer dithering. **Those helpers are not all wired into the demo.** See `docs/IMPLEMENTATION_COVERAGE.md`.

All exact transition rules are new proposed operational choices, labelled **[P]** in the specification. User-origin requirements are **[S]**; independently cited background constraints are **[B]**. The uploaded conversation does not itself provide the complete transition rules.

## File guide

| Location | Purpose |
|---|---|
| `docs/` | Private and public PDFs, editable LaTeX, source/claims registers and primary references |
| `src/dawnwood/` | Reference interpreter and mathematical helpers |
| `config/` | Default configuration and JSON Schema |
| `tests/` | Standard-library conformance tests |
| `examples/` | Preserved wavefront fixture; no invented timestamp-to-vector mapping |
| `results/` | Executed reports, 128-step trace and analytical memory CSVs |
| `gpu/` | Unvalidated CUDA device capability probe; **not a GPU kernel implementation** |
| `source/` | Unchanged supplied PDF and its SHA-256 provenance record; personal details present |
| `private/` | Supplied attribution data; not independently verified |
| `tools/` | Test, PDF-build and integrity-check utilities |

## Integrity and rebuilding

```text
python tools/verify_manifest.py
```

The manifest describes the delivered bytes; rerunning tests or rebuilding documents changes some generated files, so verify it **before** regenerating those files. The source-file digest is also recorded separately in `source/provenance.json`.

To rebuild both PDFs, install a LaTeX distribution containing the packages named in `docs/specification.tex`, then run:

```text
python tools/build_pdfs.py
```

No font files are redistributed. Rendering QA was performed on the delivered PDFs. The public PDF excludes the private appendix; the editable master remains private.

## Scope and rights

The source's claims about physical quantum effects, guaranteed deadlock avoidance, permanent L1 residency, zero PCIe traffic, 24–48 billion operational states and unconditional universality are **not established** by this package. The twelve-item claims register preserves their source locations and dispositions. The GPU target is a future deployment exercise; the CUDA probe was not compiled or run here.

Project attribution is supplied by the requester. New formal definitions, code and editorial work are AI-assisted additions. No license has been selected on the requester's behalf; third-party references are not relicensed. No legal filing or ownership verification was performed. See `RIGHTS_AND_ATTRIBUTION.md`.
