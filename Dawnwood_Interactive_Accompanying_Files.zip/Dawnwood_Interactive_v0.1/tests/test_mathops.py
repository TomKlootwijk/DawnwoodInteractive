import math
import unittest
from dawnwood.mathops import *

class MathTests(unittest.TestCase):
    def test_source_parity_example(self):
        self.assertEqual((parity_lsb(7),parity_lsb(54)),(1,0))
        self.assertEqual((parity_population(7),parity_population(54)),(1,0))
    def test_parity_definitions_are_distinct(self):
        self.assertEqual((parity_lsb(3),parity_population(3)),(1,0))
    def test_parity_rejects_negative(self):
        with self.assertRaises(ValueError): parity_population(-1)
    def test_logpolar_roundtrip(self):
        for x,y in ((2.3,4.1),(-1,3),(-2,-4),(1,-8)):
            a,b=inverse_log_polar(*log_polar(x,y,2),2)
            self.assertAlmostEqual(a,x); self.assertAlmostEqual(b,y)
    def test_origin_rejected(self):
        with self.assertRaises(ValueError): log_polar(0,0)
    def test_nonfinite_rejected(self):
        with self.assertRaises(ValueError): log_polar(math.inf,1)
    def test_quantization_error_bound(self):
        lo,hi,bits=-3.0,5.0,8
        bound=(hi-lo)/((1<<bits)-1)/2
        for i in range(101):
            rho=lo+(hi-lo)*i/100
            self.assertLessEqual(abs(decode_log_radius(quantize_log_radius(rho,lo,hi,bits),lo,hi,bits)-rho),bound+1e-12)
    def test_quantizer_rejects_range(self):
        with self.assertRaises(ValueError): quantize_log_radius(9,0,1,8)
    def test_hadamard_involution(self):
        a,b=complex(1,2),complex(3,-4)
        x,y=hadamard(*hadamard(a,b))
        self.assertAlmostEqual(abs(x-a),0); self.assertAlmostEqual(abs(y-b),0)
    def test_mixer_norm(self):
        a,b=complex(1,2),complex(3,-4)
        x,y=phase_mix(a,b,1.3)
        self.assertAlmostEqual(abs(x)**2+abs(y)**2,abs(a)**2+abs(b)**2)
    def test_mixer_phase_pi_swaps(self):
        x,y=phase_mix(1+0j,0j,math.pi)
        self.assertAlmostEqual(abs(x),0); self.assertAlmostEqual(abs(y-1),0)
    def test_source_literal_dft(self):
        for actual,wanted in zip(dft([0,2,0,1]),[3,-1j,-3,1j]):
            self.assertAlmostEqual(abs(actual-wanted),0)
    def test_dft_empty_rejected(self):
        with self.assertRaises(ValueError): dft([])
    def test_rk4_constant_field(self):
        self.assertEqual(rk4(lambda t,y:(2,-1),0,(1,3),0.5),(2.0,2.5))
    def test_rk4_fourth_order_convergence(self):
        def solve(h):
            y=(1.0,)
            for i in range(round(1/h)): y=rk4(lambda t,y:y,i*h,y,h)
            return abs(y[0]-math.e)
        self.assertGreater(solve(0.1)/solve(0.05),14)
    def test_rk4_dimension_rejected(self):
        with self.assertRaises(ValueError): rk4(lambda t,y:(1,2),0,(1,),0.1)
    def test_phyllotaxis_radial_law(self):
        points=phyllotaxis(20,2)
        for i,p in enumerate(points): self.assertAlmostEqual(math.hypot(*p)**2,4*(i+0.5))
    def test_double_contract(self):
        self.assertEqual(double_contract(((1,2),(3,4)),((2,1),(0,3))),16)
    def test_contract_shape_rejected(self):
        with self.assertRaises(ValueError): double_contract(((1,2),),((1,),))
    def test_second_difference(self):
        self.assertEqual(phase_second_difference(1,4,9),2)
    def test_blend(self):
        self.assertEqual(blend(2,6,0.25),3)
    def test_alpha_normalized(self):
        self.assertEqual(inverse_period_alpha(4,1),0.25)
        self.assertEqual(inverse_period_alpha(0.5,1),1)
    def test_alpha_zero_rejected(self):
        with self.assertRaises(ValueError): inverse_period_alpha(0)
    def test_bayer_endpoints(self):
        self.assertEqual(sum(bayer_bit(0,x,y) for x in range(4) for y in range(4)),0)
        self.assertEqual(sum(bayer_bit(1,x,y) for x in range(4) for y in range(4)),16)
    def test_bayer_midpoint(self):
        self.assertEqual(sum(bayer_bit(0.5,x,y) for x in range(4) for y in range(4)),8)
    def test_primitive_quality_labels(self):
        self.assertEqual(primitive_field("circle",(1,0)),(0.0,"exact_local_sdf"))
        self.assertEqual(primitive_field("cone",(0,0,0.5))[1],"implicit_field")
        self.assertEqual(primitive_field("apex",(0,0,0)),(0.0,"unsigned_distance"))
    def test_sphere_sign(self):
        self.assertEqual(sdf_sphere((0,0,0),1),-1)
        self.assertEqual(sdf_sphere((2,0,0),1),1)
    def test_box_distance(self):
        self.assertEqual(sdf_box((0,0),(1,1)),-1)
        self.assertAlmostEqual(sdf_box((2,2),(1,1)),math.sqrt(2))
    def test_invalid_primitive(self):
        with self.assertRaises(ValueError): primitive_field("circle",(0,0,0))
