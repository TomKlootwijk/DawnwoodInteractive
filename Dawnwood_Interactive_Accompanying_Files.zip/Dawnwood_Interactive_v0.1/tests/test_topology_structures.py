import math
import unittest
from dawnwood.topology import *
from dawnwood.structures import *

class TopologyTests(unittest.TestCase):
    def test_one_twist(self):
        u,v,s=wrap_klein(1.25,0.2,0)
        self.assertAlmostEqual(u,0.25); self.assertAlmostEqual(v,0.8); self.assertEqual(s,1)
    def test_two_twists_restore(self):
        u,v,s=wrap_klein(2.25,0.2,0)
        self.assertAlmostEqual(u,0.25); self.assertAlmostEqual(v,0.2); self.assertEqual(s,0)
    def test_negative_twist(self):
        u,v,s=wrap_klein(-0.25,0.2,0)
        self.assertAlmostEqual(u,0.75); self.assertAlmostEqual(v,0.8); self.assertEqual(s,1)
    def test_integer_twist(self):
        self.assertEqual(wrap_discrete(33,7,32,24),(1,17,1))
    def test_integer_negative_twist(self):
        self.assertEqual(wrap_discrete(-1,7,32,24),(31,17,1))
    def test_integer_multiple_crossings(self):
        self.assertEqual(wrap_discrete(97,7,32,24,1),(1,17,0))
    def test_representative_distance_invariance(self):
        a,b=(0.2,0.3),(0.8,0.7)
        self.assertAlmostEqual(klein_distance(a,b),klein_distance((1.2,-0.3),b))
        self.assertAlmostEqual(klein_distance(a,b),klein_distance(a,(0.8,1.7)))
    def test_seam_distance(self):
        self.assertAlmostEqual(klein_distance((0.99,0.2),(0.01,0.8)),0.02)
    def test_distance_symmetry(self):
        for a,b in (((0.2,0.3),(0.8,0.1)),((0.9,0.6),(0.1,0.3))):
            self.assertAlmostEqual(klein_distance(a,b),klein_distance(b,a))
    def test_distance_identity(self):
        self.assertAlmostEqual(klein_distance((0.2,0.3),(1.2,-0.3)),0)
    def test_chart_range(self):
        for u in range(-71,72):
            for v in (-51,0,37):
                a,b,s=wrap_discrete(u,v,13,17)
                self.assertTrue(0<=a<13 and 0<=b<17 and s in (0,1))
    def test_invalid_chart(self):
        with self.assertRaises(ValueError): wrap_discrete(1,1,0,7)

class StructureTests(unittest.TestCase):
    def test_bit_pack_size(self):
        self.assertEqual(len(PackedBits(65).data),9)
    def test_bit_boundaries(self):
        b=PackedBits(65)
        for i in (0,7,8,63,64): b.set(i,1)
        self.assertEqual(sum(b.get(i) for i in range(65)),5)
        b.set(8,0); self.assertEqual(b.get(7),1); self.assertEqual(b.get(8),0)
    def test_bit_bounds_rejected(self):
        b=PackedBits(8)
        with self.assertRaises(IndexError): b.set(8,1)
    def test_bit_value_rejected(self):
        with self.assertRaises(ValueError): PackedBits(8).set(1,2)
    def test_bst_every_key_and_height(self):
        for count in (1,2,7,8,31,100):
            tree=ImplicitBST(list(range(count)))
            for k in range(count):
                node,path=tree.lookup(k)
                self.assertEqual(tree.keys[node],k)
                self.assertLessEqual(len(path),math.floor(math.log2(count)))
    def test_bst_order_not_heap_values(self):
        self.assertEqual(ImplicitBST(list(range(7))).keys,[3,1,5,0,2,4,6])
    def test_bst_absent_key(self):
        with self.assertRaises(KeyError): ImplicitBST([1,5,8]).lookup(4)
    def test_bst_duplicate_rejected(self):
        with self.assertRaises(ValueError): ImplicitBST([1,1])
