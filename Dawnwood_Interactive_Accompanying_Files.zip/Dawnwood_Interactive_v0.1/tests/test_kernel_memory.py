import unittest
from dawnwood.kernel import *
from dawnwood.memory import *

class KernelTests(unittest.TestCase):
    def test_replay(self):
        a,b=Kernel(Config()),Kernel(Config())
        self.assertEqual(a.run(128),b.run(128)); self.assertEqual(a.digest(),b.digest())
    def test_seed_changes_trace(self):
        a,b=Kernel(Config(seed=756)),Kernel(Config(seed=757))
        self.assertNotEqual(a.run(32),b.run(32))
    def test_prng_nonzero(self):
        x=756
        for _ in range(10000):
            x=xorshift32(x)
            self.assertTrue(0<x<=0xFFFFFFFF)
    def test_jitter_disabled(self):
        k=Kernel(Config(jitter=False))
        initial=[(d.anchor_u,d.anchor_v) for d in k.descriptors.values()]
        trace=k.run(128)
        self.assertTrue(all(r['jitter']==0 for r in trace))
        self.assertEqual(initial,[(d.anchor_u,d.anchor_v) for d in k.descriptors.values()])
        self.assertTrue(all(d.mode==0 for d in k.descriptors.values()))
    def test_self_reference_mutates_modes(self):
        k=Kernel(Config(gate_radius=1.0))
        trace=k.run(256)
        self.assertTrue(any(r['mode_before']!=r['mode_after'] for r in trace))
    def test_anchors_move(self):
        k=Kernel(Config())
        before=[(d.anchor_u,d.anchor_v) for d in k.descriptors.values()]
        k.run(128)
        self.assertNotEqual(before,[(d.anchor_u,d.anchor_v) for d in k.descriptors.values()])
    def test_runtime_bounds(self):
        cfg=Config(); k=Kernel(cfg)
        for row in k.run(256):
            u,v,s=row['cursor_after']
            self.assertTrue(0<=u<cfg.chart_u and 0<=v<cfg.chart_v and s in (0,1))
            self.assertTrue(0<=row['address']<cfg.payload_bits)
            self.assertIn(row['output_bit'],(0,1))
    def test_immutable_keys(self):
        k=Kernel(Config()); before=k.tree.keys.copy(); k.run(128)
        self.assertEqual(before,k.tree.keys)
    def test_field_gates_writes(self):
        k=Kernel(Config(gate_radius=0.001))
        trace=k.run(128)
        self.assertTrue(any(not r['active'] for r in trace))
        self.assertTrue(all(r['output_bit']==r['input_bits'][0] for r in trace if not r['active']))
    def test_nand_truth_table(self):
        self.assertEqual([eval_bit('NAND',a,b) for a,b in ((0,0),(0,1),(1,0),(1,1))],[1,1,1,0])
    def test_invalid_seed(self):
        with self.assertRaises(ValueError): Config(seed=0)
    def test_invalid_step_count(self):
        with self.assertRaises(ValueError): Kernel(Config()).run(-1)
    def test_config_rejects_unknown_key(self):
        with self.assertRaises(TypeError): Config(unknown_parameter=1)
    def test_epoch_uint64_wrap(self):
        k=Kernel(Config()); k.epoch=0xFFFFFFFFFFFFFFFF; k.step()
        self.assertEqual(k.epoch,0)
    def test_zero_steps(self):
        k=Kernel(Config()); d=k.digest(); self.assertEqual(k.run(0),[]); self.assertEqual(k.digest(),d)

class MemoryTests(unittest.TestCase):
    def test_twelve_gib_raw(self):
        rows={r['format']:r for r in capacities(12*(1<<30))}
        self.assertEqual(rows['RGBA32F']['elements'],805306368)
        self.assertEqual(rows['BC5']['elements'],12884901888)
        self.assertEqual(rows['packed_1bit']['elements'],103079215104)
    def test_decimal_gb_distinct(self):
        rows={r['format']:r for r in capacities(12_000_000_000)}
        self.assertEqual(rows['RGBA32F']['elements'],750000000)
    def test_budget_reserve_and_copies(self):
        rows={r['format']:r for r in capacities(100,20,16,2)}
        self.assertEqual(rows['RGBA32F']['elements'],2)
        self.assertEqual(rows['BC5']['elements'],32)
    def test_oversubscribed_rejected(self):
        with self.assertRaises(ValueError): capacities(5,6)
    def test_bc5_block_rounding(self):
        self.assertEqual(bc5_bytes(4,4),16)
        self.assertEqual(bc5_bytes(5,5),64)
    def test_raw_bit_capacity_not_fractional_bytes(self):
        rows={r['format']:r for r in capacities(5,copies=2)}
        self.assertEqual(rows['packed_1bit']['elements'],16)
