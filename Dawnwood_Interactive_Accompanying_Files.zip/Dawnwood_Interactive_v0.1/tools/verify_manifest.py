"""Check delivered file bytes against MANIFEST.sha256 before regenerating files."""
from pathlib import Path
import hashlib
import sys

ROOT=Path(__file__).resolve().parents[1]
manifest=ROOT/'MANIFEST.sha256'
if not manifest.is_file():
    raise SystemExit('MANIFEST.sha256 is missing.')
failed=[]
count=0
try:
    for line in manifest.read_text(encoding='utf-8').splitlines():
        if not line or line.startswith('#'): continue
        digest,name=line.split('  ',1)
        path=(ROOT/name).resolve()
        if ROOT not in path.parents:
            raise ValueError('Manifest path is outside the package root.')
        count+=1
        if not path.is_file():
            failed.append(f'MISSING {name}')
        elif hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            failed.append(f'CHANGED {name}')
except (OSError,ValueError) as exc:
    raise SystemExit(f'Invalid manifest: {exc}')
if failed:
    print('\n'.join(failed),file=sys.stderr)
    raise SystemExit(1)
print(f'All {count} manifest entries match. This verifies file integrity, not authorship or scientific claims.')
