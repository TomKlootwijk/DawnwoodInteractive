"""Execute standard-library conformance tests and save an auditable summary."""
from pathlib import Path
import io
import json
import platform
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
stream=io.StringIO()
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
(ROOT/'results').mkdir(exist_ok=True)
(ROOT/'results'/'test_report.txt').write_text(stream.getvalue(),encoding='utf-8')
report={'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skipped':len(result.skipped),'success':result.wasSuccessful(),
        'python':platform.python_version(),'platform':platform.platform(),
        'profile':'P-finite-0.1 plus standalone mathematical helpers',
        'gpu_compiled':False,'gpu_executed':False,
        'scope':'Unit and invariant tests; not empirical physics or performance validation.'}
(ROOT/'results'/'test_summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(stream.getvalue()); print(json.dumps(report,indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
