"""Build both PDF editions; requires pdflatex and the packages in the master."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import sys

ROOT=Path(__file__).resolve().parents[1]
DOCS=ROOT/'docs'
if not shutil.which('pdflatex'):
    raise SystemExit('pdflatex was not found. Install a LaTeX distribution first.')
try:
    with tempfile.TemporaryDirectory(prefix='dawnwood_pdf_') as temp:
        for stem,target in [('specification','Dawnwood_Interactive_Formalization.pdf'),
                            ('public','Dawnwood_Interactive_Public.pdf')]:
            for _ in range(3):
                proc=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',
                                     f'-output-directory={temp}',f'{stem}.tex'],cwd=DOCS,
                                    text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                    timeout=90)
                if proc.returncode:
                    print(proc.stdout[-8000:],file=sys.stderr)
                    raise SystemExit(f'LaTeX build failed for {stem}.')
            shutil.copy2(Path(temp)/f'{stem}.pdf',DOCS/target)
            print(f'Built {DOCS/target}')
except subprocess.TimeoutExpired:
    raise SystemExit('LaTeX build timed out.')
print('Rebuilt PDFs should be visually checked before redistribution. The release manifest now needs regeneration.')
