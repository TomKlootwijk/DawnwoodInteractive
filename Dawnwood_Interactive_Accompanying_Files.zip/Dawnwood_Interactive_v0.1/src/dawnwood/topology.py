"""Intrinsic flat Klein quotient, not a global signed-distance bottle in R^3."""
from __future__ import annotations
import math

def wrap_klein(u: float, v: float, orientation: int = 0) -> tuple[float,float,int]:
    if not math.isfinite(u) or not math.isfinite(v) or orientation not in (0,1):
        raise ValueError("invalid chart coordinate or orientation")
    crossings = math.floor(u)
    odd = crossings & 1
    return u-crossings, ((-v) if odd else v) % 1.0, orientation ^ odd

def wrap_discrete(u: int, v: int, width: int, height: int,
                  orientation: int = 0) -> tuple[int,int,int]:
    if any(type(x) is not int for x in (u,v,width,height,orientation)):
        raise ValueError("discrete coordinates require integers")
    if width <= 0 or height <= 0 or orientation not in (0,1):
        raise ValueError("invalid chart size or orientation")
    crossings, uu = divmod(u,width)
    odd = crossings & 1
    return uu, ((-v) if odd else v) % height, orientation ^ odd

def klein_distance(a: tuple[float,float], b: tuple[float,float]) -> float:
    """Exact flat-quotient metric to float precision; not ambient 3D distance."""
    u,v,_ = wrap_klein(*a)
    x,y,_ = wrap_klein(*b)
    best = math.inf
    for m in (-1,0,1):
        dy = v - ((-y) if (m & 1) else y)
        dy -= round(dy)
        best = min(best, math.hypot(u-(x+m),dy))
    return best

def klein_disk_field(a: tuple[float,float], centre: tuple[float,float], radius: float) -> float:
    if not math.isfinite(radius) or radius <= 0:
        raise ValueError("radius must be finite and positive")
    return klein_distance(a,centre)-radius
