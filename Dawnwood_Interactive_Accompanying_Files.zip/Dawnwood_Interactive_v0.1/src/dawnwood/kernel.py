"""Proposed P-profile finite self-referential interpreter.

The uploaded conversation does not specify these transition rules. They are a
transparent, executable design choice, not a claim that the source implied them.
Single cursor; fixed descriptor set; single-threaded CPU. No physical qubits.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
import hashlib
import json
import math
from .structures import PackedBits, ImplicitBST
from .topology import wrap_discrete, klein_disk_field

OPCODES = ("NOP","NOT","XOR","AND","NAND","COPY_B","SET0","SET1")

def xorshift32(state: int) -> int:
    if type(state) is not int or not 0 < state <= 0xFFFFFFFF:
        raise ValueError("PRNG state must be a nonzero uint32")
    x = state
    x ^= (x << 13) & 0xFFFFFFFF
    x ^= x >> 17
    x ^= (x << 5) & 0xFFFFFFFF
    return x & 0xFFFFFFFF

def eval_bit(opcode: str, a: int, b: int) -> int:
    if opcode not in OPCODES or a not in (0,1) or b not in (0,1):
        raise ValueError("invalid bit operation")
    return {"NOP":a,"NOT":a^1,"XOR":a^b,"AND":a&b,
            "NAND":1^(a&b),"COPY_B":b,"SET0":0,"SET1":1}[opcode]

@dataclass
class Descriptor:
    key: int
    opcode0: str
    opcode1: str
    anchor_u: int
    anchor_v: int
    radius: float
    mode: int = 0

@dataclass(frozen=True)
class Config:
    payload_bits: int = 256
    chart_u: int = 32
    chart_v: int = 24
    descriptor_count: int = 7
    seed: int = 756
    jitter: bool = True
    psi_seconds: float = 0.01
    gate_radius: float = 0.45
    def __post_init__(self) -> None:
        for name in ("payload_bits","chart_u","chart_v","descriptor_count","seed"):
            if type(getattr(self,name)) is not int:
                raise ValueError(f"{name} must be an integer")
        if not 1 <= self.payload_bits <= 100_000_000:
            raise ValueError("payload_bits outside reference safety range [1,100000000]")
        if not 2 <= self.chart_u <= 65535 or not 2 <= self.chart_v <= 65535:
            raise ValueError("chart dimensions must be in [2,65535]")
        if not 1 <= self.descriptor_count <= 4096:
            raise ValueError("descriptor_count must be in [1,4096]")
        if not 0 < self.seed <= 0xFFFFFFFF:
            raise ValueError("seed must be a nonzero uint32")
        if type(self.jitter) is not bool:
            raise ValueError("jitter must be Boolean")
        if not math.isfinite(self.psi_seconds) or self.psi_seconds <= 0:
            raise ValueError("psi_seconds must be finite and positive")
        if not math.isfinite(self.gate_radius) or not 0 < self.gate_radius <= 1:
            raise ValueError("gate_radius must be in (0,1]")

class Kernel:
    def __init__(self, config: Config):
        self.config = config
        self.payload = PackedBits(config.payload_bits)
        for i in range(config.payload_bits):
            self.payload.set(i, ((i ^ config.seed).bit_count() & 1))
        self.descriptors: dict[int,Descriptor] = {}
        for i in range(config.descriptor_count):
            self.descriptors[i] = Descriptor(
                i, OPCODES[i % len(OPCODES)], OPCODES[(i+1) % len(OPCODES)],
                (5*i) % config.chart_u, (7*i) % config.chart_v, config.gate_radius)
        self.tree = ImplicitBST(list(self.descriptors))
        self.u = self.v = self.orientation = self.epoch = self.last_bit = 0
        self.prng = config.seed
    def snapshot(self) -> dict:
        return {"config":asdict(self.config),"epoch":self.epoch,"u":self.u,"v":self.v,
                "orientation":self.orientation,"last_bit":self.last_bit,"prng":self.prng,
                "payload_hex":self.payload.hex(),
                "descriptors":[asdict(self.descriptors[k]) for k in sorted(self.descriptors)]}
    def digest(self) -> str:
        raw = json.dumps(self.snapshot(),sort_keys=True,separators=(",",":"),allow_nan=False).encode()
        return hashlib.sha256(raw).hexdigest()
    def step(self) -> dict:
        cfg = self.config
        before = [self.u,self.v,self.orientation]
        if cfg.jitter:
            self.prng = xorshift32(self.prng)
            jitter = self.prng & 1
        else:
            jitter = 0
        key = (self.u+3*self.v+self.epoch+self.last_bit+jitter) % cfg.descriptor_count
        node,path = self.tree.lookup(key)
        descriptor = self.descriptors[key]
        mode_before = descriptor.mode
        descriptor.mode ^= jitter & self.last_bit
        if cfg.jitter:
            descriptor.anchor_u,descriptor.anchor_v,_ = wrap_discrete(
                descriptor.anchor_u+(2*jitter-1),descriptor.anchor_v,cfg.chart_u,cfg.chart_v)
        field = klein_disk_field((self.u/cfg.chart_u,self.v/cfg.chart_v),
                                 (descriptor.anchor_u/cfg.chart_u,descriptor.anchor_v/cfg.chart_v),
                                 descriptor.radius)
        active = field <= 0.0
        address = (self.u+3*self.v) % cfg.payload_bits
        a,b = self.payload.get(address),self.payload.get((address+1)%cfg.payload_bits)
        opcode = descriptor.opcode1 if descriptor.mode else descriptor.opcode0
        out = eval_bit(opcode,a,b) if active else a
        if active:
            self.payload.set(address,out)
        # The second pinion moves along a transported local vertical direction.
        dv = (1 if out else -1) * (-1 if self.orientation else 1)
        self.u,self.v,self.orientation = wrap_discrete(self.u+1,self.v+dv,cfg.chart_u,cfg.chart_v,self.orientation)
        self.last_bit = out
        row = {"epoch":self.epoch,"logical_time_seconds":self.epoch*cfg.psi_seconds,
               "jitter":jitter,"key":key,"bst_node":node,"route_bits":path,
               "mode_before":mode_before,"mode_after":descriptor.mode,"opcode":opcode,
               "anchor":[descriptor.anchor_u,descriptor.anchor_v],"field":field,"active":active,
               "address":address,"input_bits":[a,b],"output_bit":out,
               "cursor_before":before,"cursor_after":[self.u,self.v,self.orientation]}
        self.epoch = (self.epoch + 1) & 0xFFFFFFFFFFFFFFFF
        return row
    def run(self,steps: int) -> list[dict]:
        if type(steps) is not int or not 0 <= steps <= 1_000_000:
            raise ValueError("steps must be in [0,1000000]")
        return [self.step() for _ in range(steps)]
