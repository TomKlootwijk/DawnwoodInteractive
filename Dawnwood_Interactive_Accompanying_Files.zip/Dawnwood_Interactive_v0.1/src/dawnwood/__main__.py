"""Run with PYTHONPATH=src python -m dawnwood (Python 3.10+)."""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import sys
from .kernel import Config,Kernel
from .memory import capacities

def main() -> int:
    parser = argparse.ArgumentParser(description="Dawnwood finite reference profile; no GPU required")
    subs = parser.add_subparsers(dest="command",required=True)
    demo = subs.add_parser("demo",help="run finite interpreter and save a replay trace")
    demo.add_argument("--config",type=Path,default=Path("config/reference.json"))
    demo.add_argument("--steps",type=int,default=128)
    demo.add_argument("--out",type=Path,default=Path("results/demo"))
    mem = subs.add_parser("memory",help="calculate capacities, without allocating VRAM")
    mem.add_argument("--total-bytes",type=int,default=12*(1<<30))
    mem.add_argument("--reserve-bytes",type=int,default=2*(1<<30))
    mem.add_argument("--fixed-bytes",type=int,default=0)
    mem.add_argument("--copies",type=int,default=1)
    mem.add_argument("--out",type=Path,default=Path("results/memory.csv"))
    args = parser.parse_args()
    try:
        if args.command == "demo":
            raw = json.loads(args.config.read_text(encoding="utf-8"))
            if not isinstance(raw,dict):
                raise ValueError("config must be a JSON object")
            cfg = Config(**raw)
            if not 0 <= args.steps <= 1_000_000:
                raise ValueError("steps must be in [0,1000000]")
            args.out.mkdir(parents=True,exist_ok=True)
            kernel = Kernel(cfg)
            # Stream traces so memory does not grow with the number of epochs.
            with (args.out/"trace.jsonl").open("w",encoding="utf-8") as f:
                for _ in range(args.steps):
                    f.write(json.dumps(kernel.step(),sort_keys=True,allow_nan=False)+"\n")
            snap = kernel.snapshot()
            (args.out/"snapshot.json").write_text(json.dumps(snap,indent=2,sort_keys=True)+"\n",encoding="utf-8")
            report = {"profile":"P-finite-0.1","steps":args.steps,"state_sha256":kernel.digest(),
                      "physical_quantum_claim":False,"gpu_executed":False}
            (args.out/"summary.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
            print(json.dumps(report,indent=2))
        else:
            rows = capacities(args.total_bytes,args.reserve_bytes,args.fixed_bytes,args.copies)
            args.out.parent.mkdir(parents=True,exist_ok=True)
            with args.out.open("w",encoding="utf-8",newline="") as f:
                writer=csv.DictWriter(f,fieldnames=list(rows[0]))
                writer.writeheader(); writer.writerows(rows)
            print(f"Wrote {args.out}; no device allocation was attempted.")
    except (OSError,ValueError,TypeError) as exc:
        print(f"error: {exc}",file=sys.stderr)
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
