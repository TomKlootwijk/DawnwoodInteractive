"""Analytical storage comparisons; entries have DIFFERENT semantic capacity."""
from __future__ import annotations
from fractions import Fraction

FORMATS = (("RGBA32F",Fraction(16),"four float32 scalars"),
           ("RGBA16F",Fraction(8),"four float16 scalars"),
           ("RGBA8",Fraction(4),"four 8-bit channels"),
           ("RG8",Fraction(2),"two 8-bit channels"),
           ("BC5",Fraction(1),"two lossy block-decoded channels; full blocks only"),
           ("uint32",Fraction(4),"one exact 32-bit word"),
           ("packed_1bit",Fraction(1,8),"one exact Boolean; no per-item metadata"),
           ("proposed_record32",Fraction(32),"one illustrative 32-byte descriptor/state record"))

def capacities(total_bytes: int, reserve_bytes: int = 0,
               fixed_bytes: int = 0, copies: int = 1) -> list[dict]:
    if any(type(x) is not int for x in (total_bytes,reserve_bytes,fixed_bytes,copies)):
        raise ValueError("byte counts and copy count must be integers")
    if min(total_bytes,reserve_bytes,fixed_bytes) < 0 or copies < 1:
        raise ValueError("invalid budget")
    budget = total_bytes-reserve_bytes-fixed_bytes
    if budget < 0:
        raise ValueError("reserve and fixed overhead exceed total")
    rows=[]
    for name,bpe,meaning in FORMATS:
        n = int(Fraction(budget)/(copies*bpe))
        if name == "BC5":
            n = (budget//(copies*16))*16
        if name == "packed_1bit":
            n = (budget//copies)*8
        rows.append({"format":name,"bytes_per_element":float(bpe),"elements":n,
                     "total_bytes":total_bytes,"usable_bytes":budget,"copies":copies,"meaning":meaning})
    return rows

def bc5_bytes(width: int,height: int) -> int:
    if type(width) is not int or type(height) is not int or min(width,height) <= 0:
        raise ValueError("texture dimensions must be positive integers")
    return 16*((width+3)//4)*((height+3)//4)
