"""Dawnwood Interactive: proposed finite reference profile, not a quantum device."""
__version__ = "0.1.0"
