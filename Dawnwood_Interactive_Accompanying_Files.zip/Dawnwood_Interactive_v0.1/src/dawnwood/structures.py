"""Lossless bit payload and an actual ordered implicit binary search tree."""
from __future__ import annotations

class PackedBits:
    def __init__(self, size: int):
        if type(size) is not int or size <= 0:
            raise ValueError("bit count must be positive")
        self.size = size
        self.data = bytearray((size+7)//8)
    def _check(self,index: int) -> None:
        if type(index) is not int or not 0 <= index < self.size:
            raise IndexError("bit address outside payload")
    def get(self,index: int) -> int:
        self._check(index)
        return (self.data[index>>3] >> (index & 7)) & 1
    def set(self,index: int,value: int) -> None:
        self._check(index)
        if value not in (0,1):
            raise ValueError("bit value must be 0 or 1")
        mask = 1 << (index & 7)
        if value:
            self.data[index>>3] |= mask
        else:
            self.data[index>>3] &= 255 ^ mask
    def hex(self) -> str:
        return self.data.hex()

class ImplicitBST:
    """Complete array, in-order sorted keys, children 2i+1 and 2i+2.

    Values are immutable keys. Mutable operator descriptors live separately.
    A one-bit comparison is a route decision; it is not a one-bit node record.
    """
    def __init__(self,keys: list[int]):
        if not keys or any(type(k) is not int for k in keys) or len(set(keys)) != len(keys):
            raise ValueError("BST keys must be distinct integers")
        ordered = iter(sorted(keys))
        self.keys = [0]*len(keys)
        def fill(index: int) -> None:
            if index >= len(keys):
                return
            fill(2*index+1)
            self.keys[index] = next(ordered)
            fill(2*index+2)
        fill(0)
    def lookup(self,key: int) -> tuple[int,list[int]]:
        index = 0
        path: list[int] = []
        while index < len(self.keys):
            node_key = self.keys[index]
            if key == node_key:
                return index,path
            right = int(key > node_key)
            path.append(right)
            index = 2*index+1+right
        raise KeyError(key)
