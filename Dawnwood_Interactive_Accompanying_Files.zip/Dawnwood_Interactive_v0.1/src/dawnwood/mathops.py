"""Explicit proposed semantics for the source's mathematical vocabulary.

These helpers are separate from the finite-bit demonstration in kernel.py.
Only circle/sphere/box are advertised here as exact Euclidean signed distances.
The source's T, pyramid and cone are implicit fields, not guaranteed exact SDFs.
"""
from __future__ import annotations
import cmath
import math
from collections.abc import Callable, Sequence

TAU = 2.0 * math.pi
GOLDEN_RATIO = (1.0 + math.sqrt(5.0)) / 2.0
GOLDEN_ANGLE = TAU * (1.0 - 1.0 / GOLDEN_RATIO)

def _finite(*xs: float) -> None:
    if not all(math.isfinite(x) for x in xs):
        raise ValueError("all numeric inputs must be finite")

def parity_lsb(value: int) -> int:
    if type(value) is not int or value < 0:
        raise ValueError("parity input must be a nonnegative integer")
    return value & 1

def parity_population(value: int) -> int:
    if type(value) is not int or value < 0:
        raise ValueError("parity input must be a nonnegative integer")
    return value.bit_count() & 1

def log_polar(x: float, y: float, r0: float = 1.0) -> tuple[float, float]:
    _finite(x, y, r0)
    r = math.hypot(x, y)
    if r == 0.0 or r0 <= 0.0:
        raise ValueError("log-polar requires r>0 and reference radius r0>0")
    return math.log(r / r0), math.atan2(y, x) % TAU

def inverse_log_polar(rho: float, phi: float, r0: float = 1.0) -> tuple[float, float]:
    _finite(rho, phi, r0)
    if r0 <= 0.0:
        raise ValueError("r0 must be positive")
    try:
        r = r0 * math.exp(rho)
    except OverflowError as exc:
        raise ValueError("decoded radius overflows") from exc
    if not math.isfinite(r) or r == 0.0:
        raise ValueError("decoded radius is outside the representable positive range")
    return r * math.cos(phi), r * math.sin(phi)

def quantize_log_radius(rho: float, lo: float, hi: float, bits: int) -> int:
    """Nearest-bin quantizer; midpoint ties round upward. No silent clipping."""
    _finite(rho, lo, hi)
    if type(bits) is not int or not 1 <= bits <= 32 or hi <= lo or not lo <= rho <= hi:
        raise ValueError("invalid quantizer domain")
    return min((1 << bits) - 1, math.floor((rho-lo)/(hi-lo)*((1<<bits)-1) + 0.5))

def decode_log_radius(q: int, lo: float, hi: float, bits: int) -> float:
    _finite(lo, hi)
    if type(bits) is not int or not 1 <= bits <= 32 or hi <= lo:
        raise ValueError("invalid quantizer domain")
    if type(q) is not int or not 0 <= q < (1 << bits):
        raise ValueError("invalid quantized value")
    return lo + q * (hi-lo)/((1 << bits)-1)

def hadamard(a: complex, b: complex) -> tuple[complex, complex]:
    _finite(a.real, a.imag, b.real, b.imag)
    s = math.sqrt(0.5)
    return (a+b)*s, (a-b)*s

def phase_mix(a: complex, b: complex, phi: float) -> tuple[complex, complex]:
    """Proposed double-pinion mixer U(phi)=H diag(1,exp(i phi)) H."""
    _finite(phi)
    x, y = hadamard(a, b)
    return hadamard(x, y * cmath.exp(1j * phi))

def dft(values: Sequence[complex]) -> list[complex]:
    """Unnormalised forward DFT. O(M^2) reference, not an FFT."""
    if not values:
        raise ValueError("DFT requires a nonempty sequence")
    for z in values:
        _finite(z.real, z.imag)
    n = len(values)
    return [sum(z * cmath.exp(-1j*TAU*k*t/n) for t, z in enumerate(values)) for k in range(n)]

def rk4(f: Callable[[float, tuple[float, ...]], Sequence[float]],
        t: float, y: Sequence[float], h: float) -> tuple[float, ...]:
    """One classical RK4 step. No post-step impulse or noise correction is implicit."""
    _finite(t, h, *y)
    if h <= 0.0 or not y:
        raise ValueError("RK4 requires a positive step and a nonempty state")
    yy = tuple(y)
    def slope(tt: float, state: tuple[float, ...]) -> tuple[float, ...]:
        out = tuple(f(tt, state))
        if len(out) != len(yy):
            raise ValueError("derivative dimension mismatch")
        _finite(*out)
        return out
    def advance(k: tuple[float, ...], scale: float) -> tuple[float, ...]:
        return tuple(v + scale*d for v, d in zip(yy, k))
    k1 = slope(t, yy)
    k2 = slope(t+h/2, advance(k1, h/2))
    k3 = slope(t+h/2, advance(k2, h/2))
    k4 = slope(t+h, advance(k3, h))
    out = tuple(v+h*(a+2*b+2*c+d)/6 for v,a,b,c,d in zip(yy,k1,k2,k3,k4))
    _finite(*out)
    return out

def phyllotaxis(count: int, scale: float = 1.0) -> list[tuple[float, float]]:
    """Planar golden-angle seeds. No claim of uniform area density on a Klein bottle."""
    if type(count) is not int or count < 0 or scale <= 0.0:
        raise ValueError("invalid phyllotaxis parameters")
    _finite(scale)
    return [(scale*math.sqrt(i+0.5)*math.cos(i*GOLDEN_ANGLE),
             scale*math.sqrt(i+0.5)*math.sin(i*GOLDEN_ANGLE)) for i in range(count)]

def phase_second_difference(previous: float, current: float, following: float) -> float:
    """Unwrapped second difference; wrapped phases must first be unwrapped by caller."""
    _finite(previous, current, following)
    return following - 2.0*current + previous

def double_contract(a: Sequence[Sequence[float]], b: Sequence[Sequence[float]]) -> float:
    """Real rank-two Frobenius contraction A:B, not a cross product."""
    if not a or not b or len(a) != len(b) or not a[0]:
        raise ValueError("matrices must be nonempty and have the same shape")
    cols = len(a[0])
    if any(len(row) != cols for row in a) or any(len(row) != cols for row in b):
        raise ValueError("matrices must be rectangular and have the same shape")
    flat = [v for matrix in (a,b) for row in matrix for v in row]
    _finite(*flat)
    return sum(x*y for ra,rb in zip(a,b) for x,y in zip(ra,rb))

def blend(a: float, b: float, weight: float) -> float:
    _finite(a,b,weight)
    if not 0.0 <= weight <= 1.0:
        raise ValueError("blend weight must be in [0,1]")
    return (1-weight)*a + weight*b

def inverse_period_alpha(period: float, reference_period: float = 1.0) -> float:
    """Proposed dimensionless display A=clip(T_ref/T_period,0,1)."""
    _finite(period, reference_period)
    if period <= 0.0 or reference_period <= 0.0:
        raise ValueError("periods must be positive")
    return min(1.0, reference_period/period)

BAYER4 = ((0,8,2,10),(12,4,14,6),(3,11,1,9),(15,7,13,5))

def bayer_bit(value: float, x: int, y: int) -> int:
    """Optional downstream ordered dithering, not a camera Bayer colour filter."""
    _finite(value)
    if not 0 <= value <= 1 or type(x) is not int or type(y) is not int:
        raise ValueError("invalid dithering arguments")
    return int(value > (BAYER4[y % 4][x % 4]+0.5)/16.0)

def sdf_sphere(point: Sequence[float], radius: float) -> float:
    if len(point) not in (2,3) or radius <= 0.0:
        raise ValueError("circle/sphere requires a 2D/3D point and positive radius")
    _finite(*point, radius)
    return math.sqrt(sum(x*x for x in point))-radius

def sdf_box(point: Sequence[float], half_extents: Sequence[float]) -> float:
    if not point or len(point) != len(half_extents) or any(b <= 0.0 for b in half_extents):
        raise ValueError("invalid box dimensions")
    _finite(*point,*half_extents)
    q = [abs(x)-b for x,b in zip(point,half_extents)]
    return math.sqrt(sum(max(v,0.0)**2 for v in q)) + min(max(q),0.0)

def primitive_field(kind: str, point: Sequence[float]) -> tuple[float, str]:
    """Unit prototype fields; dimensions and quality are part of the contract."""
    _finite(*point)
    if kind == "circle" and len(point) == 2:
        return sdf_sphere(point,1.0), "exact_local_sdf"
    if kind == "sphere" and len(point) == 3:
        return sdf_sphere(point,1.0), "exact_local_sdf"
    if kind == "apex" and len(point) in (2,3):
        return math.sqrt(sum(v*v for v in point)), "unsigned_distance"
    if kind == "T" and len(point) == 2:
        x,y = point
        # A vertical stem and horizontal top bar; overlap makes this a field.
        return min(sdf_box((x,y),(0.2,1.0)), sdf_box((x,y-0.8),(0.8,0.2))), "implicit_field"
    if kind == "pyramid" and len(point) == 3:
        x,y,z = point
        return max(abs(x)+z-1.0,abs(y)+z-1.0,-z), "implicit_field"
    if kind == "cone" and len(point) == 3:
        x,y,z = point
        return max(math.hypot(x,y)+z-1.0,-z), "implicit_field"
    raise ValueError("unsupported primitive or dimension")
