# Proposed decisions and unresolved alternatives

These decisions create P-finite-0.1; they are not silently attributed to the original discussion.

**D01 — Classical reference interpretation.** Use a software interpreter, with optional complex-amplitude calculations in separate helpers. Do not describe a GPU implementation as a physical quantum device.

**D02 — Intrinsic topology.** Use the flat quotient `(u,v)~(u,v+1)~(u+1,-v)`, including an explicit orientation bit for the cursor. This replaces no source text; it supplies a tractable interpretation of the requested surface constraint. An ambient immersed 3D field remains an alternative requiring its own distance and sheet semantics.

**D03 — One-bit scope.** One bit describes a Boolean datum, route decision or variant selection. Coordinates, keys, opcodes, intervals and descriptors require additional storage.

**D04 — Genuine BST.** Choose complete Eytzinger-style array layout with sorted in-order keys. Mutation does not change keys. The tree is not presented as a geometric nearest-neighbor structure.

**D05 — Executable fields.** Couple a typed activation field to a whitelisted action. A geometric zero set alone is not an instruction definition.

**D06 — Seeded jitter.** Use nonzero xorshift32 for replay. Move the selected anchor by minus or plus one horizontal quantum and toggle its variant when `jitter & last_output` is one. This is a proposal, not a derived stochastic physical law.

**D07 — Explicit self-reference.** Previous output influences the next key and descriptor mutation. Catalogue size is fixed. The reference neither discovers new instruction kinds nor proves task optimization.

**D08 — T ambiguity.** Retain T as unresolved in the source record. The standalone alpha helper explicitly chooses a period and computes `min(1,T_ref/T_period)`; a matrix inverse or inverse temperature is not treated as equivalent.

**D09 — RK4 ambiguity.** Supply classical RK4. Discuss a post-step two-quantum Y impulse as a possible separate convention, but do not enable it or call it a stabilizing correction.

**D10 — Source wavefront.** Preserve the vector and time label independently. No timestamp-to-vector function is inferred.

**D11 — Output isolation.** Bayer means optional ordered dithering in this helper. Square output samples do not define the core computational domain.

**D12 — Finite epoch.** Use a wrapping uint64 epoch so the declared internal state is finite. Logical time labels wrap with that epoch. External trace history is not included in the bounded-state claim.

**D13 — Explicit capacity units.** Compare 12 decimal GB, 12 GiB and an illustrative 10 GiB working budget. Count Booleans, texture texels and records separately. No VRAM allocation was performed.

**D14 — Private attribution.** Retain the current-request identity string in a private appendix and record the source discrepancy there. Do not classify or verify the identifier, infer an invention date or select a legal license.

## Decisions needed for a larger profile

Specify how amplitude mixing couples to transport; the intended geometrical SDF and its accuracy class; coordinate units; persistent fields and history; descriptor ABI; event handling within continuous integration; compile/load/store/branch interfaces; and same-semantics baseline tasks. Any change must receive a profile version and matching tests.
