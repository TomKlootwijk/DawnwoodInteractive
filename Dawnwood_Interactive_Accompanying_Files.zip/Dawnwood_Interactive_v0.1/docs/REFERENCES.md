# References

External primary sources checked 16 September 2026. They support background constraints, not Dawnwood performance or novelty.

**[S0] User-supplied source.** double-slit-theory.pdf, 24-page exported conversation.

source/double-slit-theory.pdf

**[B1] Feynman, Leighton and Sands.** The Feynman Lectures on Physics, Vol. III, ch. 1: Quantum Behavior.

https://www.feynmanlectures.caltech.edu/III_01.html

**[B2] IBM Quantum.** Bits, gates, and circuits: H gate.

https://quantum.cloud.ibm.com/learning/en/courses/utility-scale-quantum-computing/bits-gates-and-circuits

**[B3] Allen Hatcher.** Algebraic Topology, pp. 51, 102 and 256: Klein quotient and non-embedding.

https://pi.math.cornell.edu/~hatcher/AT/AT.pdf

**[B4] NVIDIA.** GeForce RTX 50 Series Gaming Laptops, specifications.

https://www.nvidia.com/en-eu/geforce/laptops/50-series/

**[B5] NVIDIA.** CUDA Programming Guide, 2.3 Writing SIMT Kernels: global and shared memory.

https://docs.nvidia.com/cuda/cuda-programming-guide/02-basics/writing-cuda-kernels.html

**[B6] NVIDIA.** CUDA Programming Guide, 4.14 L2 Cache Control.

https://docs.nvidia.com/cuda/cuda-programming-guide/04-special-topics/l2-cache-control.html

**[B7] Microsoft.** Texture Block Compression in Direct3D 11: BC4 and BC5 formats.

https://learn.microsoft.com/en-us/windows/win32/direct3d11/texture-block-compression-in-direct3d-11

**[B8] Microsoft.** Block Compression (Direct3D 10): lossy formats and shader resource use.

https://learn.microsoft.com/en-us/windows/win32/direct3d10/d3d10-graphics-programming-guide-resources-block-compression

**[B9] NVIDIA.** CUDA C++ Programming Guide (legacy), device memory, execution and runtime APIs.

https://docs.nvidia.com/cuda/cuda-c-programming-guide/

