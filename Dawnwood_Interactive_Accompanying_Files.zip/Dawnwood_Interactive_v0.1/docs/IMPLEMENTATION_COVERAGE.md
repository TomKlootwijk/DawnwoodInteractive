# Implementation coverage

All implementation semantics below are proposed profile choices [P]. Source intentions and earlier AI assertions remain separately identified in `SOURCE_TRACEABILITY.md` and `CLAIMS_REGISTER.md`.

| Feature | Delivered status | Location / limitation |
|---|---|---|
| One-bit payload | Integrated, lossless | `structures.PackedBits`; byte-packed CPU storage |
| Actual implicit BST | Integrated | Complete array with in-order sorted immutable keys; not a spatial nearest-neighbor index |
| One-bit jitter | Integrated | Reproducible xorshift32; not hardware randomness or a quantum fluctuation |
| Self-referential mutation | Integrated | Previous output affects routing and selected opcode variant |
| Operator anchors moving on the quotient | Integrated | Mutable scalar-field anchors, canonicalized at seams |
| Intrinsic Klein distance / field | Integrated | Flat quotient metric; no global ambient 3D Klein SDF |
| Double-pinion surface transport | Integrated | Exact discrete chart and an explicit transported orientation bit |
| Hadamard amplitude hinge | Standalone tested helper | `mathops.hadamard`, `mathops.phase_mix`; no physical qubits |
| Log-polar encoding | Standalone tested helper | Origin rejection; finite radial quantization; not integrated into finite routing |
| Literal FT vector | Fixture and standalone test | `[0,2,0,1]`; DFT `[3,-i,-3,i]`; timestamp conversion unspecified |
| RK4 | Standalone tested helper | No post-step Y-up impulse enabled; not integrated in bit demo |
| Phyllotaxis | Standalone tested helper | Planar golden-angle seed rule; no surface-density or GPU-coherence guarantee |
| Circle / sphere | Standalone tested helpers | Exact local Euclidean SDFs |
| T / pyramid / cone | Standalone helpers | Unit implicit fields, not certified exact distances; not all shape properties exhaustively tested |
| Apex | Standalone tested helper | Unsigned point distance |
| Colon | Standalone tested helper | Same-shaped real matrix Frobenius contraction; not cross product |
| Delta-delta-phi | Standalone tested helper | Second difference of unwrapped phases |
| Blend | Standalone tested helper | Scalar linear blend |
| Inverse-T alpha | Standalone tested helper | Chosen period interpretation with dimensionless normalization |
| Bayer output | Standalone tested helper | Ordered dithering, not a colour-filter sensor model |
| Complete coupled amplitude/SDF engine | Not delivered | Need coupling, units, boundary, precision and update contracts |
| CUDA device probe | Source delivered, unvalidated | Queries properties/free memory; no large allocation |
| GPU execution kernel / shaders | Not delivered | No GPU compilation, execution or benchmark was performed |
| Turing-completeness construction | Not delivered | Fixed finite interpreter is not such a proof |
| Legal or intellectual-property registration | Not performed | Technical preparation and supplied attribution only |
