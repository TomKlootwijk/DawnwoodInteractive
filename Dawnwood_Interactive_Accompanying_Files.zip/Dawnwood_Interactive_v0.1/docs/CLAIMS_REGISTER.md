# Claims register

These are dispositions of earlier AI assertions, not silent edits to the source. The unchanged source remains available for comparison.

## C01 | source pp. 5-7

**Earlier AI assertion:** Parity, bit shifts or Y-up RK4 corrections remove quantum uncertainty.

**Disposition:** Not established by the source; digital state operations are defined separately.

## C02 | source pp. 6

**Earlier AI assertion:** One-bit jitter leaks energy into higher dimensions.

**Disposition:** No supporting measurement or mathematical model supplied; not adopted.

## C03 | source pp. 8

**Earlier AI assertion:** The colon is a tensor cross product.

**Disposition:** Source symbol retained; P-profile defines a rank-two Frobenius contraction instead, explicitly.

## C04 | source pp. 10-12

**Earlier AI assertion:** Inverse-T alpha automatically corrects errors or prunes impossible trajectories.

**Disposition:** Not established. T is ambiguous; alpha is only a normalized display parameter in the helper.

## C05 | source pp. 13-17

**Earlier AI assertion:** A Klein-bottle SDF prevents collapse and is a self-sustaining quantum computer.

**Disposition:** Not established. The reference is a classical finite interpreter with an intrinsic quotient chart.

## C06 | source pp. 15

**Earlier AI assertion:** Jitter guarantees escape from deadlock and optimized paths.

**Disposition:** No objective function or proof supplied; finite seeded dynamics can repeat.

## C07 | source pp. 18

**Earlier AI assertion:** A LUT can be permanently placed in bare-metal L1 cache with no stalls.

**Disposition:** Not an application-level guarantee; use documented device memory and explicit kernel scratch storage.

## C08 | source pp. 19-20

**Earlier AI assertion:** BC5 packs all RGBA/quantum state losslessly and forces PCIe traffic to zero.

**Disposition:** BC5 is a two-channel lossy texture format. Residency and traffic need explicit workload measurements.

## C09 | source pp. 21

**Earlier AI assertion:** Standard rendering is exponential and a coordinate matrix costs O(N).

**Disposition:** Not an adequate comparison. Use matched per-item and whole-workload definitions.

## C10 | source pp. 21

**Earlier AI assertion:** A single one-bit mutation updates all state globally in O(1).

**Disposition:** One descriptor change can be O(1); processing all affected data and synchronization are separate work.

## C11 | source pp. 22

**Earlier AI assertion:** Removing pointers establishes 24-48 billion operational states on 12 GB.

**Disposition:** No complete record format or overhead budget supplied. Report bits, texels and records separately.

## C12 | source pp. 23

**Earlier AI assertion:** Hadamard plus feedback proves Turing completeness and expresses anything.

**Disposition:** No universality construction supplied. The delivered bounded-memory interpreter is not a universality proof.

