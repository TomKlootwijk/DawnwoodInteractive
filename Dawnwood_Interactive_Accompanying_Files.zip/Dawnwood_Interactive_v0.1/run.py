"""Portable entry point; no installation or environment-variable changes needed."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from dawnwood.__main__ import main
if __name__ == '__main__':
    raise SystemExit(main())
