# Attribution and handling record

Prepared on 16 September 2026 for Tom Klootwijk, with the project name Dawnwood Interactive as supplied in the request.

The uploaded source is retained unchanged. Original user conceptual statements are distinguished from the earlier AI's responses. New equations, operational choices, code and editorial structure are AI-assisted formalization work, not retroactively assigned to the source transcript.

This package does not verify identity, exclusive rights, novelty, company status or an invention date. No company, trademark or patent filing, notarization, signature or other legal registration has been performed. No distribution license has been selected on the requester's behalf. Citations do not transfer rights in the cited material. No third-party font files or external reference PDFs are included.

The complete archive is private working material. The private PDF, editable LaTeX, original source PDF and `private/attribution.json` contain supplied personal information. The public PDF omits the private appendix but retains name/project attribution. Review any larger subset before sharing it.
