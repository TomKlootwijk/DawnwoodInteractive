# GPU target: capability probe only

`device_probe.cu` is **not** a GPU port of the finite interpreter. It queries the chosen CUDA device and emits JSON containing its name, compute capability, total/free bytes, shared-memory sizes, warp size, SM count and L2 size. It does not allocate a large working set.

It was **not compiled or executed** in this release environment. On a target with a compatible NVIDIA driver, CUDA toolkit and host C++ compiler:

```text
nvcc -std=c++17 device_probe.cu -o device_probe
```

Then run `./device_probe` on Linux or `device_probe.exe` on Windows. An optional first argument selects the device index. The free-byte result is a snapshot, not a permanent allocation guarantee. API background: reference [B9] in `docs/REFERENCES.md`.

A later GPU profile must explicitly define packed-word ownership, descriptor stride, read/write epochs, synchronization, numeric tolerances, kernel launch bounds and memory headroom. Shared-memory scratch storage must not be assumed persistent across ordinary launches; see [B5]. L2 access policies are not a universal cache-pinning facility; see [B6]. BC5 is not lossless opcode storage; see [B7–B8].

Begin by matching the CPU profile on bounded test cases. No GPU speedup, cache residency, maximum state capacity, no-hot-swap behavior or zero-PCIe result is asserted here.
