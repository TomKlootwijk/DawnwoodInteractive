// Optional NVIDIA CUDA capability probe. This is NOT the Dawnwood GPU kernel.
// It queries properties only; it does not allocate or saturate GPU memory.
// Build on the target system: nvcc -std=c++17 device_probe.cu -o device_probe
// Not compiled or executed in the supplied validation environment.
#include <cuda_runtime.h>
#include <cstdlib>
#include <iostream>
#include <string>
#include <stdexcept>

static void check(cudaError_t result, const char* operation) {
    if (result != cudaSuccess) {
        std::cerr << operation << ": " << cudaGetErrorString(result) << "\n";
        std::exit(1);
    }
}
static std::string quoted(const char* text) {
    std::string s="\"";
    for (const char* p=text; *p; ++p) {
        if (*p=='"' || *p=='\\') s+='\\';
        s+=*p;
    }
    return s+'"';
}
int main(int argc, char** argv) {
    int count=0;
    check(cudaGetDeviceCount(&count),"cudaGetDeviceCount");
    if (count==0) { std::cerr<<"No CUDA device detected.\n"; return 1; }
    int device=0;
    if (argc>1) {
        try {
            std::size_t used=0;
            device=std::stoi(argv[1],&used);
            if (used!=std::string(argv[1]).size()) throw std::invalid_argument("trailing text");
        } catch (...) { std::cerr<<"Expected an integer device index.\n"; return 2; }
    }
    if (device<0 || device>=count) { std::cerr<<"Device index out of range.\n"; return 2; }
    check(cudaSetDevice(device),"cudaSetDevice");
    cudaDeviceProp p{};
    check(cudaGetDeviceProperties(&p,device),"cudaGetDeviceProperties");
    std::size_t free_bytes=0,total_bytes=0;
    check(cudaMemGetInfo(&free_bytes,&total_bytes),"cudaMemGetInfo");
    std::cout<<"{\n"
        <<"  \"device\": "<<device<<",\n"
        <<"  \"name\": "<<quoted(p.name)<<",\n"
        <<"  \"compute_major\": "<<p.major<<",\n"
        <<"  \"compute_minor\": "<<p.minor<<",\n"
        <<"  \"reported_global_bytes\": "<<p.totalGlobalMem<<",\n"
        <<"  \"runtime_total_bytes\": "<<total_bytes<<",\n"
        <<"  \"runtime_free_bytes\": "<<free_bytes<<",\n"
        <<"  \"shared_bytes_per_block\": "<<p.sharedMemPerBlock<<",\n"
        <<"  \"shared_bytes_per_sm\": "<<p.sharedMemPerMultiprocessor<<",\n"
        <<"  \"warp_size\": "<<p.warpSize<<",\n"
        <<"  \"sm_count\": "<<p.multiProcessorCount<<",\n"
        <<"  \"l2_bytes\": "<<p.l2CacheSize<<"\n}\n";
    return 0;
}
